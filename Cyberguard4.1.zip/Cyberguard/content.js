// Cyber Guard Pro - Advanced Content Script with Parental Controls
// Comprehensive security monitoring and user protection

// Safe wrapper for chrome.runtime.sendMessage to handle extension context invalidation
function safeSendMessage(message, callback) {
  try {
    if (chrome.runtime?.id) {
      chrome.runtime.sendMessage(message, callback);
    } else {
      console.log('Extension context invalidated, message not sent:', message);
      if (callback) callback({ error: 'Extension context invalidated' });
    }
  } catch (error) {
    if (error.message.includes('Extension context invalidated')) {
      console.log('Extension context invalidated, content script will reload on next navigation');
    } else {
      console.error('Error sending message to background:', error);
    }
    if (callback) callback({ error: error.message });
  }
}

class CyberGuardContent {
  constructor() {
    this.isInitialized = false;
    this.profanityFilter = null; // Will be initialized from profanity-filter.js
    this.parentalControlsEnabled = false;
    this.parentalSettings = {};
    this.contentObserver = null;
    this.securityConfig = {
      phishingPatterns: [
        /urgent.*action.*required/i,
        /verify.*account.*immediately/i,
        /click.*here.*to.*claim/i,
        /limited.*time.*offer/i,
        /suspicious.*activity.*detected/i
      ],
      maliciousDomains: [
        'suspicious-site.com',
        'fake-bank.net',
        'phishing-example.org'
      ]
    };
    this.threatLevel = 'low';
    this.init();
  }

  async init() {
    if (this.isInitialized) return;
    this.isInitialized = true;
    
    // Initialize profanity filter from the global ProfanityFilter class
    if (typeof ProfanityFilter !== 'undefined') {
      this.profanityFilter = new ProfanityFilter();
      await this.profanityFilter.loadSettings();
    }
    
    // Load parental control settings from background
    await this.loadParentalSettings();
    
    this.setupEventListeners();
    this.performInitialScan();
    this.showWelcomeMessage();
    
    // Start content monitoring for parental controls
    if (this.parentalControlsEnabled) {
      this.startContentMonitoring();
    }
  }

  async loadParentalSettings() {
    return new Promise((resolve) => {
      safeSendMessage({ type: 'getParentalStats' }, (response) => {
        if (response && !response.error) {
          this.parentalControlsEnabled = response.enabled;
          this.parentalSettings = response;
        }
        resolve();
      });
    });
  }

  setupEventListeners() {
    // Enhanced input monitoring
    document.addEventListener('input', this.handleInputEvent.bind(this), true);
    document.addEventListener('focusin', this.handleFocusEvent.bind(this), true);
    document.addEventListener('focusout', this.handleFocusOutEvent.bind(this), true);
    document.addEventListener('paste', this.handlePasteEvent.bind(this), true);
    
    // Form submission monitoring
    document.addEventListener('submit', this.handleFormSubmit.bind(this), true);
    
    // Click monitoring for suspicious links
    document.addEventListener('click', this.handleClickEvent.bind(this), true);
    
    // Page visibility changes
    document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleBackgroundMessage(message, sender, sendResponse);
      return true;
    });
  }

  handleBackgroundMessage(message, sender, sendResponse) {
    switch (message.action) {
      case 'showBigPopup':
        this.showBigPopup(message.reason);
        sendResponse({ status: 'popup shown' });
        break;
        
      case 'updateParentalSettings':
        this.updateParentalSettings(message.settings);
        sendResponse({ status: 'settings updated' });
        break;
        
      case 'toggleParentalControl':
        this.handleParentalControlToggle(message.enabled);
        sendResponse({ status: 'toggle handled' });
        break;
        
      default:
        sendResponse({ error: 'Unknown action' });
    }
  }

  // Start monitoring content for inappropriate material
  startContentMonitoring() {
    if (!this.profanityFilter || !this.parentalControlsEnabled) return;

    // Remove existing observer if any
    if (this.contentObserver) {
      this.contentObserver.disconnect();
    }

    // Monitor dynamic content changes
    this.contentObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.TEXT_NODE || node.nodeType === Node.ELEMENT_NODE) {
              this.scanContentForProfanity(node);
            }
          });
        }
      });
    });

    this.contentObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });

    // Initial scan of existing content
    this.scanContentForProfanity(document.body);
  }

  // Stop content monitoring
  stopContentMonitoring() {
    if (this.contentObserver) {
      this.contentObserver.disconnect();
      this.contentObserver = null;
    }
    this.unblurAllContent();
  }

  // Scan content for profanity and inappropriate material
  scanContentForProfanity(element) {
    if (!this.profanityFilter || !this.parentalControlsEnabled) return;

    try {
      const result = this.profanityFilter.scanContent(element);
      
      if (result.found && result.matches.length > 0) {
        this.handleInappropriateContent(element, result);
        
        // Log the incident to background script
        safeSendMessage({
          type: 'logContentIncident',
          incident: {
            url: window.location.href,
            domain: window.location.hostname,
            content: result.matches[0].text,
            language: result.matches[0].language,
            severity: result.matches[0].severity,
            action: 'blocked',
            userAgent: navigator.userAgent,
            timestamp: Date.now()
          }
        });

        // Notify background about content blocked
        safeSendMessage({
          type: 'notifyContentBlocked',
          details: {
            url: window.location.href,
            domain: window.location.hostname,
            wordsFound: result.matches.length,
            timestamp: Date.now()
          }
        });
      }
    } catch (error) {
      console.error('Error scanning content for profanity:', error);
    }
  }

  // Handle detection of inappropriate content
  handleInappropriateContent(element, result) {
    // Show content warning overlay
    this.showContentWarning(result);
    
    // Blur or hide the inappropriate content
    this.blurInappropriateContent(element);
    
    // Award achievement for parental protection
    safeSendMessage({
      type: 'updateAchievements',
      data: {
        type: 'content_blocked',
        count: 1,
        timestamp: Date.now()
      }
    });
  }

  // Show content warning overlay
  showContentWarning(result) {
    // Remove existing warning if present
    const existingWarning = document.getElementById('cyberguard-content-warning');
    if (existingWarning) {
      existingWarning.remove();
    }

    const warningOverlay = document.createElement('div');
    warningOverlay.id = 'cyberguard-content-warning';
    warningOverlay.className = 'cyberguard-content-warning';
    
    warningOverlay.innerHTML = `
      <div class="content-warning-card">
        <div class="warning-icon">🚫</div>
        <div class="warning-title">Content Blocked</div>
        <div class="warning-message">
          This page contains inappropriate content that has been filtered by parental controls.
          <br><br>
          <strong>${result.matches.length}</strong> inappropriate word${result.matches.length !== 1 ? 's' : ''} detected.
        </div>
        <div class="warning-actions">
          <button class="warning-btn primary" id="cyberguard-leave-page">
            🏠 Go Back
          </button>
          <button class="warning-btn secondary" id="cyberguard-override-warning">
            🔓 Enter PIN to Continue
          </button>
        </div>
      </div>
    `;

    // Add CSS styles for the warning overlay
    const style = document.createElement('style');
    style.textContent = `
      .cyberguard-content-warning {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.8);
        backdrop-filter: blur(10px);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2147483647;
        animation: cyberguard-warning-fadein 0.3s ease-out;
      }
      
      .content-warning-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        text-align: center;
        max-width: 500px;
        margin: 20px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        animation: cyberguard-warning-bounce 0.5s ease-out;
      }
      
      .warning-icon {
        font-size: 64px;
        margin-bottom: 20px;
      }
      
      .warning-title {
        font-size: 28px;
        font-weight: bold;
        color: #dc3545;
        margin-bottom: 16px;
      }
      
      .warning-message {
        font-size: 16px;
        color: #333;
        line-height: 1.5;
        margin-bottom: 30px;
      }
      
      .warning-actions {
        display: flex;
        gap: 15px;
        justify-content: center;
        flex-wrap: wrap;
      }
      
      .warning-btn {
        padding: 12px 24px;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      
      .warning-btn.primary {
        background: #28a745;
        color: white;
      }
      
      .warning-btn.primary:hover {
        background: #218838;
        transform: translateY(-2px);
      }
      
      .warning-btn.secondary {
        background: #6c757d;
        color: white;
      }
      
      .warning-btn.secondary:hover {
        background: #5a6268;
        transform: translateY(-2px);
      }
      
      @keyframes cyberguard-warning-fadein {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      
      @keyframes cyberguard-warning-bounce {
        0% { transform: scale(0.8) translateY(-20px); opacity: 0; }
        100% { transform: scale(1) translateY(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    document.body.appendChild(warningOverlay);

    // Add event listeners
    document.getElementById('cyberguard-leave-page').addEventListener('click', () => {
      window.history.back();
    });

    document.getElementById('cyberguard-override-warning').addEventListener('click', () => {
      this.showPinPrompt();
    });

    // Auto-hide after 15 seconds if no interaction
    setTimeout(() => {
      if (document.getElementById('cyberguard-content-warning')) {
        this.hideProfanityWarning();
      }
    }, 15000);
  }

  // Show PIN prompt for override
  showPinPrompt() {
    const pinOverlay = document.createElement('div');
    pinOverlay.id = 'cyberguard-pin-overlay';
    pinOverlay.innerHTML = `
      <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.9);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2147483648;
      ">
        <div style="
          background: white;
          padding: 40px;
          border-radius: 16px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.3);
          text-align: center;
          max-width: 400px;
          margin: 20px;
        ">
          <h3 style="margin-bottom: 20px; color: #333; font-size: 24px;">Enter Parental Control PIN</h3>
          <input type="password" id="cyberguard-pin-input" 
                 style="padding: 16px; border: 2px solid #ddd; border-radius: 8px; 
                        font-size: 18px; text-align: center; margin-bottom: 24px; width: 250px;
                        font-family: monospace; letter-spacing: 2px;"
                 placeholder="Enter PIN" maxlength="6">
          <br>
          <button id="cyberguard-verify-pin" 
                  style="background: #4a90e2; color: white; border: none; 
                         padding: 16px 32px; border-radius: 8px; cursor: pointer; margin-right: 12px;
                         font-size: 16px; font-weight: 600; transition: all 0.3s ease;">
            🔓 Verify PIN
          </button>
          <button id="cyberguard-cancel-pin" 
                  style="background: #6c757d; color: white; border: none; 
                         padding: 16px 32px; border-radius: 8px; cursor: pointer;
                         font-size: 16px; font-weight: 600; transition: all 0.3s ease;">
            ❌ Cancel
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(pinOverlay);

    const pinInput = document.getElementById('cyberguard-pin-input');
    pinInput.focus();

    document.getElementById('cyberguard-verify-pin').addEventListener('click', () => {
      this.verifyPin(pinInput.value, pinOverlay);
    });

    document.getElementById('cyberguard-cancel-pin').addEventListener('click', () => {
      pinOverlay.remove();
    });

    // Allow Enter key to verify PIN
    pinInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.verifyPin(pinInput.value, pinOverlay);
      }
    });
  }

  verifyPin(pin, overlay) {
    safeSendMessage({ type: 'verifyParentalPin', pin: pin }, (response) => {
      if (response && response.valid) {
        // PIN is correct - remove warnings and allow access
        document.getElementById('cyberguard-content-warning')?.remove();
        overlay.remove();
        this.unblurAllContent();
        this.showSuccessNotification('PIN verified. Content access granted for this session.');
        
        // Log bypass incident
        safeSendMessage({
          type: 'logContentIncident',
          incident: {
            url: window.location.href,
            domain: window.location.hostname,
            action: 'bypassed',
            timestamp: Date.now()
          }
        });
      } else {
        // Invalid PIN
        const pinInput = document.getElementById('cyberguard-pin-input');
        pinInput.style.borderColor = '#dc3545';
        pinInput.style.backgroundColor = '#ffe6e6';
        pinInput.value = '';
        pinInput.placeholder = 'Invalid PIN - Try again';
        pinInput.focus();
        
        setTimeout(() => {
          pinInput.style.borderColor = '#ddd';
          pinInput.style.backgroundColor = 'white';
          pinInput.placeholder = 'Enter PIN';
        }, 2000);
      }
    });
  }

  // Blur inappropriate content
  blurInappropriateContent(element) {
    if (element.nodeType === Node.ELEMENT_NODE) {
      element.style.filter = 'blur(15px)';
      element.style.pointerEvents = 'none';
      element.style.userSelect = 'none';
      element.setAttribute('data-cyberguard-blurred', 'true');
    }
  }

  // Unblur all previously blurred content
  unblurAllContent() {
    const blurredElements = document.querySelectorAll('[data-cyberguard-blurred="true"]');
    blurredElements.forEach(element => {
      element.style.filter = '';
      element.style.pointerEvents = '';
      element.style.userSelect = '';
      element.removeAttribute('data-cyberguard-blurred');
    });
  }

  // Handle parental control toggle
  handleParentalControlToggle(enabled) {
    this.parentalControlsEnabled = enabled;
    
    if (enabled) {
      this.startContentMonitoring();
      this.showSuccessNotification('Parental controls enabled for this page');
    } else {
      this.stopContentMonitoring();
      this.showSuccessNotification('Parental controls disabled for this page');
    }
  }

  // Update parental control settings
  updateParentalSettings(settings) {
    this.parentalSettings = { ...this.parentalSettings, ...settings };
    
    if (this.profanityFilter) {
      this.profanityFilter.updateSettings(settings);
    }
    
    this.showSuccessNotification('Parental control settings updated');
  }

  // Hide profanity warning
  hideProfanityWarning() {
    const warning = document.getElementById('cyberguard-content-warning');
    if (warning) {
      warning.style.opacity = '0';
      warning.style.transform = 'scale(0.8)';
      setTimeout(() => warning.remove(), 300);
    }
  }

  // Show success notification
  showSuccessNotification(message) {
    this.showSiteSuggestionPopup(message, '#28a745');
  }

  // Existing security functionality
  performInitialScan() {
    this.scanForPhishingIndicators();
    this.checkDomainReputation();
    this.analyzePageSecurity();
  }

  scanForPhishingIndicators() {
    const pageText = document.body.textContent.toLowerCase();
    const suspicious = this.securityConfig.phishingPatterns.some(pattern => 
      pattern.test(pageText)
    );
    
    if (suspicious) {
      this.threatLevel = 'high';
      this.showSecurityAlert('Potential phishing attempt detected on this page!', 'warning');
    }
  }

  checkDomainReputation() {
    const domain = window.location.hostname;
    const isMalicious = this.securityConfig.maliciousDomains.includes(domain);
    
    if (isMalicious) {
      this.threatLevel = 'critical';
      this.showBigPopup('🚨 DANGER: This website has been flagged as malicious! Leave immediately for your safety.');
    }
  }

  analyzePageSecurity() {
    const securityFeatures = {
      https: window.location.protocol === 'https:',
      mixedContent: this.detectMixedContent(),
      suspiciousScripts: this.detectSuspiciousScripts()
    };

    if (!securityFeatures.https && this.isLoginPage()) {
      this.showSecurityAlert('Warning: This login page is not secure (no HTTPS)', 'warning');
    }
  }

  detectMixedContent() {
    const images = document.querySelectorAll('img[src^="http:"]');
    const scripts = document.querySelectorAll('script[src^="http:"]');
    return images.length > 0 || scripts.length > 0;
  }

  detectSuspiciousScripts() {
    const scripts = document.querySelectorAll('script');
    return Array.from(scripts).some(script => {
      const src = script.src || script.textContent;
      return /eval\(|document\.write\(|fromCharCode/i.test(src);
    });
  }

  isLoginPage() {
    const passwordFields = document.querySelectorAll('input[type="password"]');
    const loginKeywords = /login|signin|sign.?in|log.?in/i;
    const pageText = document.title + document.body.textContent;
    return passwordFields.length > 0 || loginKeywords.test(pageText);
  }

  handleInputEvent(event) {
    const target = event.target;
    if (!this.isInputElement(target)) return;

    const value = target.value || target.textContent || '';
    
    // Check for sensitive data in inappropriate fields
    if (this.containsSensitiveData(value) && !this.isSensitiveField(target)) {
      this.showSecurityAlert('Caution: Sensitive information detected in unexpected field', 'info');
    }

    // Real-time password strength feedback
    if (target.type === 'password') {
      this.showPasswordStrengthFeedback(target, value);
    }
  }

  handleFocusEvent(event) {
    const target = event.target;
    
    if (target.type === 'password') {
      this.showPasswordSuggestion(target, '🔐 Tip: Use a strong, unique password with 12+ characters');
    }

    if (this.isSensitiveField(target)) {
      this.showSecurityAlert('Sensitive field detected - be cautious about sharing personal information', 'info');
    }
  }

  handleFocusOutEvent(event) {
    this.removePasswordSuggestion();
    this.removePasswordStrengthIndicator();
  }

  handlePasteEvent(event) {
    const clipboardData = event.clipboardData?.getData('text') || '';
    
    if (this.containsSensitiveData(clipboardData)) {
      const confirmed = confirm(
        'You are pasting what appears to be sensitive information. Are you sure this website is trustworthy?'
      );
      
      if (!confirmed) {
        event.preventDefault();
        this.showSecurityAlert('Paste operation cancelled for your security', 'info');
      }
    }
  }

  handleFormSubmit(event) {
    const form = event.target;
    const formData = new FormData(form);
    let hasSensitiveData = false;

    for (const [key, value] of formData.entries()) {
      if (this.containsSensitiveData(value.toString())) {
        hasSensitiveData = true;
        break;
      }
    }

    if (hasSensitiveData && !window.location.protocol.includes('https')) {
      event.preventDefault();
      this.showBigPopup('🛡️ Form submission blocked! This page is not secure (no HTTPS). Your sensitive data could be intercepted.');
    }
  }

  handleClickEvent(event) {
    const target = event.target.closest('a');
    if (!target) return;

    const href = target.href;
    if (this.isSuspiciousLink(href)) {
      event.preventDefault();
      const confirmed = confirm(
        `This link appears suspicious: ${href}\n\nAre you sure you want to continue?`
      );
      
      if (confirmed) {
        window.open(href, '_blank');
      } else {
        this.showSecurityAlert('Suspicious link click prevented', 'success');
      }
    }
  }

  handleVisibilityChange() {
    if (document.hidden) {
      safeSendMessage({ type: 'stopCounting' });
    } else {
      safeSendMessage({ type: 'startCounting' });
    }
  }

  // Utility methods
  isSuspiciousLink(href) {
    if (!href) return false;
    
    const suspiciousPatterns = [
      /bit\.ly|tinyurl|short\.link/i,
      /\.tk$|\.ml$|\.ga$/i,
      /download.*now|click.*here.*win/i
    ];
    
    return suspiciousPatterns.some(pattern => pattern.test(href));
  }

  containsSensitiveData(text) {
    if (!text) return false;
    
    const patterns = [
      /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/, // Credit card
      /\b\d{3}-\d{2}-\d{4}\b/, // SSN
      /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/, // Aadhaar
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/, // Email
      /\b\d{10,}\b/ // Phone numbers
    ];
    
    return patterns.some(pattern => pattern.test(text));
  }

  isSensitiveField(element) {
    const sensitiveTypes = ['password', 'email', 'tel'];
    const sensitiveNames = ['password', 'credit', 'card', 'cvv', 'ssn', 'aadhaar', 'pin'];
    const sensitivePatterns = /password|credit|card|cvv|ssn|aadhaar|pin|security|secret/i;
    
    return sensitiveTypes.includes(element.type) ||
           sensitiveNames.some(name => (element.name || '').toLowerCase().includes(name)) ||
           sensitivePatterns.test(element.placeholder || '') ||
           sensitivePatterns.test(element.id || '');
  }

  isInputElement(element) {
    return element.tagName === 'INPUT' || 
           element.tagName === 'TEXTAREA' || 
           element.isContentEditable;
  }

  // Password strength analysis
  showPasswordStrengthFeedback(inputElement, password) {
    const strength = this.calculatePasswordStrength(password);
    let existing = document.querySelector('.cyberguard-password-strength');
    
    if (existing) existing.remove();
    
    const indicator = document.createElement('div');
    indicator.className = 'cyberguard-password-strength';
    indicator.innerHTML = `
      <div style="font-size: 12px; margin-top: 4px; padding: 4px 8px; border-radius: 4px; background: ${strength.color}; color: white;">
        Password Strength: ${strength.text} (${strength.score}/5)
      </div>
    `;
    
    const rect = inputElement.getBoundingClientRect();
    indicator.style.position = 'absolute';
    indicator.style.top = (window.scrollY + rect.bottom + 4) + 'px';
    indicator.style.left = (window.scrollX + rect.left) + 'px';
    indicator.style.zIndex = '2147483647';
    
    document.body.appendChild(indicator);
  }

  calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[^a-zA-Z0-9]/.test(password)) score++;
    
    const levels = [
      { score: 0, text: 'Very Weak', color: '#dc3545' },
      { score: 1, text: 'Weak', color: '#fd7e14' },
      { score: 2, text: 'Fair', color: '#ffc107' },
      { score: 3, text: 'Good', color: '#20c997' },
      { score: 4, text: 'Strong', color: '#28a745' },
      { score: 5, text: 'Very Strong', color: '#007bff' }
    ];
    
    return { ...levels[Math.min(score, 5)], score };
  }

  removePasswordStrengthIndicator() {
    const existing = document.querySelector('.cyberguard-password-strength');
    if (existing) existing.remove();
  }

  // Enhanced security alerts and popups
  showSecurityAlert(message, type = 'info') {
    const colors = {
      info: '#17a2b8',
      warning: '#ffc107',
      success: '#28a745',
      danger: '#dc3545'
    };
    
    this.showSiteSuggestionPopup(message, colors[type]);
  }

  showWelcomeMessage() {
    setTimeout(() => {
      this.showSiteSuggestionPopup('🛡️ Cyber Guard Pro is protecting you! Stay vigilant and browse safely.', '#4a90e2');
    }, 1000);
  }

  showSiteSuggestionPopup(message, color = 'rgba(74,144,226,0.95)') {
    let popup = document.createElement('div');
    popup.className = 'cyberguard-suggestion-popup';
    popup.textContent = message;
    popup.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: ${color};
      color: white;
      padding: 12px 22px;
      border-radius: 14px;
      font-family: Inter, Arial, sans-serif;
      font-size: 15px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.13);
      z-index: 2147483647;
      opacity: 0;
      transition: opacity 0.3s;
      max-width: 300px;
      word-wrap: break-word;
    `;
    
    document.body.appendChild(popup);
    setTimeout(() => { popup.style.opacity = '1'; }, 10);
    setTimeout(() => {
      popup.style.opacity = '0';
      setTimeout(() => { popup.remove(); }, 300);
    }, 5000);
  }

  showPasswordSuggestion(inputElement, message) {
    this.removePasswordSuggestion();
    
    let popup = document.createElement('div');
    popup.className = 'cyberguard-password-suggestion';
    popup.textContent = message;
    popup.style.cssText = `
      position: absolute;
      background: rgba(74,144,226,0.95);
      color: white;
      padding: 7px 16px;
      border-radius: 10px;
      font-family: Inter, Arial, sans-serif;
      font-size: 13px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.13);
      z-index: 2147483647;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.3s;
      max-width: 250px;
      word-wrap: break-word;
      white-space: normal;
    `;
    
    const rect = inputElement.getBoundingClientRect();
    popup.style.top = (window.scrollY + rect.top + rect.height / 2 - 18) + 'px';
    popup.style.left = (window.scrollX + rect.right + 12) + 'px';
    
    document.body.appendChild(popup);
    setTimeout(() => { popup.style.opacity = '1'; }, 10);
  }

  removePasswordSuggestion() {
    let existing = document.querySelector('.cyberguard-password-suggestion');
    if (existing) existing.remove();
  }

  showBigPopup(message) {
    const oldPopup = document.getElementById('cyberguard-big-popup');
    if (oldPopup) oldPopup.remove();

    const overlay = document.createElement('div');
    overlay.id = 'cyberguard-big-popup';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 2147483647;
      animation: cyberguard-fadein 0.5s;
    `;

    document.body.style.pointerEvents = 'none';
    overlay.style.pointerEvents = 'auto';

    const card = document.createElement('div');
    card.style.cssText = `
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(16px);
      border-radius: 28px;
      box-shadow: 0 12px 40px rgba(74,144,226,0.18), 0 2px 12px rgba(0,0,0,0.08);
      padding: 48px 40px 36px 40px;
      min-width: 350px;
      max-width: 90vw;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
    `;

    card.innerHTML = `
      <div style="margin-bottom: 12px;">
        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" style="display:block;margin:auto;">
          <defs>
            <linearGradient id="shieldGradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#4a90e2"/>
              <stop offset="100%" stop-color="#50e3c2"/>
            </linearGradient>
          </defs>
          <g>
            <path d="M30 6 L54 14 V28 C54 44 30 54 30 54 C30 54 6 44 6 28 V14 L30 6 Z" fill="url(#shieldGradient)" stroke="#357ABD" stroke-width="2"/>
            <path d="M30 20 L40 30 L26 44 L20 36" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
          </g>
        </svg>
      </div>
      <div style="font-size: 1.45rem; font-weight: 800; color: #357ABD; margin-bottom: 14px; letter-spacing: 0.5px;">
        Cyber Guard Pro Alert
      </div>
      <div style="font-size: 1.1rem; color: #222; margin-bottom: 8px; font-weight: 500;">
        ${message}
      </div>
      <button id="cyberguard-close-btn" style="margin-top: 28px; padding: 14px 36px; border: none; border-radius: 14px; background: linear-gradient(90deg, #4a90e2 0%, #50e3c2 100%); color: #fff; font-size: 1.1rem; font-weight: 700; box-shadow: 0 2px 8px rgba(74,144,226,0.10); cursor: pointer; outline: none; position: relative; overflow: hidden; transition: background 0.2s, transform 0.1s;">OK, I Understand</button>
    `;

    card.querySelector('#cyberguard-close-btn').addEventListener('click', () => {
      overlay.remove();
      document.body.style.pointerEvents = '';
    });

    // Add CSS animation if not exists
    if (!document.getElementById('cyberguard-popup-style')) {
      const style = document.createElement('style');
      style.id = 'cyberguard-popup-style';
      style.innerHTML = `@keyframes cyberguard-fadein { from { opacity: 0; } to { opacity: 1; } }`;
      document.head.appendChild(style);
    }

    overlay.appendChild(card);
    document.body.appendChild(overlay);
  }
}

// Initialize the content script
const cyberGuardContent = new CyberGuardContent();
