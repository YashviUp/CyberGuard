// Cyber Guard Pro - Multilingual Profanity Filter
// Comprehensive bad word detection for parental controls

class ProfanityFilter {
    constructor() {
        this.badWords = {
            english: {
                mild: ['damn', 'hell', 'crap', 'piss'],
                moderate: ['shit', 'fuck', 'bitch', 'ass', 'bastard', 'whore', 'slut'],
                strict: ['pussy', 'cock', 'dick', 'cunt', 'motherfucker', 'asshole']
            },
            hindi: {
                mild: ['बकवास', 'भड़वा', 'गधा'],
                moderate: ['रंडी', 'कुत्ता', 'हरामी', 'साला', 'कमीना', 'चूतिया'],
                strict: ['भोसड़ी', 'मादरचोद', 'भैंचोद', 'गांडू', 'रंडी', 'लौड़ा']
            },
            spanish: {
                mild: ['mierda', 'joder', 'coño'],
                moderate: ['puta', 'hijo de puta', 'cabrón', 'pendejo', 'gilipollas'],
                strict: ['polla', 'coño', 'chocho', 'maricón', 'bollera']
            },
            tamil: {
                mild: ['முட்டாள்', 'பைத்தியம்'],
                moderate: ['கேவலம்', 'நாய்', 'பன்னி', 'ஓட்டா', 'லூசு'],
                strict: ['தேவிடியா', 'ஓம்மால', 'பூல', 'கூதி', 'சுன்னி']
            },
            malayalam: {
                mild: ['മണ്ടൻ', 'ചെറുക്കൻ'],
                moderate: ['പട്ടി', 'തായോളി', 'പരസ്പരം', 'വെറുപ്പ്'],
                strict: ['തേവിടിച്ചി', 'കുണ്ണ', 'പൂർ', 'മൈര്']
            },
            telugu: {
                mild: ['మూర్ఖుడు', 'పిచ్చి'],
                moderate: ['కుక్క', 'హరామి', 'దొంగ', 'తప్పు'],
                strict: ['బొస్సు', 'కామిన', 'రండి', 'లంజ']
            }
        };

        // Additional patterns for common workarounds
        this.patterns = {
            leetSpeak: {
                'a': ['@', '4'],
                'e': ['3'],
                'i': ['1', '!'],
                'o': ['0'],
                's': ['$', '5'],
                't': ['7'],
                'l': ['1'],
                'g': ['9']
            },
            spacing: /[.\-_\s*]+/g,
            repeating: /(.)\1{2,}/g
        };

        this.settings = {
            enabled: true,
            languages: ['english', 'hindi', 'spanish', 'tamil', 'malayalam', 'telugu'],
            strength: 'moderate',
            pinProtected: false,
            pin: null
        };
    }

    // Load settings from storage
    async loadSettings() {
        try {
            const result = await chrome.storage.local.get(['parentalControlSettings']);
            if (result.parentalControlSettings) {
                this.settings = { ...this.settings, ...result.parentalControlSettings };
            }
        } catch (error) {
            console.error('Failed to load parental control settings:', error);
        }
    }

    // Save settings to storage
    async saveSettings() {
        try {
            await chrome.storage.local.set({ parentalControlSettings: this.settings });
        } catch (error) {
            console.error('Failed to save parental control settings:', error);
        }
    }

    // Normalize text for detection
    normalizeText(text) {
        let normalized = text.toLowerCase();
        
        // Remove spacing patterns
        normalized = normalized.replace(this.patterns.spacing, '');
        
        // Handle leet speak
        Object.entries(this.patterns.leetSpeak).forEach(([letter, replacements]) => {
            replacements.forEach(replacement => {
                normalized = normalized.replace(new RegExp(replacement.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), letter);
            });
        });
        
        // Handle repeated characters
        normalized = normalized.replace(this.patterns.repeating, '$1');
        
        return normalized;
    }

    // Check if text contains profanity
    containsProfanity(text) {
        if (!this.settings.enabled) return { found: false };

        const normalizedText = this.normalizeText(text);
        const foundWords = [];
        const languages = this.settings.languages;
        const strength = this.settings.strength;

        // Get all relevant word lists based on strength
        const wordLists = [];
        languages.forEach(lang => {
            if (this.badWords[lang]) {
                switch (strength) {
                    case 'strict':
                        wordLists.push(...this.badWords[lang].mild || []);
                        wordLists.push(...this.badWords[lang].moderate || []);
                        wordLists.push(...this.badWords[lang].strict || []);
                        break;
                    case 'moderate':
                        wordLists.push(...this.badWords[lang].mild || []);
                        wordLists.push(...this.badWords[lang].moderate || []);
                        break;
                    case 'mild':
                        wordLists.push(...this.badWords[lang].mild || []);
                        break;
                }
            }
        });

        // Check for matches
        wordLists.forEach(word => {
            const normalizedWord = this.normalizeText(word);
            if (normalizedText.includes(normalizedWord)) {
                foundWords.push(word);
            }
        });

        return {
            found: foundWords.length > 0,
            words: foundWords,
            count: foundWords.length
        };
    }

    // Check multiple text sources (useful for web pages)
    checkContent(content) {
        const results = [];
        
        // Check different text sources
        const textSources = [
            content.textContent || '',
            content.innerHTML || '',
            content.title || '',
            content.alt || ''
        ];

        textSources.forEach(text => {
            if (text && text.trim()) {
                const result = this.containsProfanity(text);
                if (result.found) {
                    results.push({
                        text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
                        ...result
                    });
                }
            }
        });

        return {
            found: results.length > 0,
            results: results,
            totalWords: results.reduce((sum, r) => sum + r.count, 0)
        };
    }

    // Validate PIN
    validatePin(inputPin) {
        return this.settings.pin && this.settings.pin === inputPin;
    }

    // Set new PIN
    setPin(newPin) {
        this.settings.pin = newPin;
        this.settings.pinProtected = true;
        this.saveSettings();
    }

    // Remove PIN protection
    removePin() {
        this.settings.pin = null;
        this.settings.pinProtected = false;
        this.saveSettings();
    }

    // Toggle parental controls (requires PIN if protected)
    toggleProtection(pin = null) {
        if (this.settings.pinProtected && !this.validatePin(pin)) {
            return { success: false, error: 'Invalid PIN' };
        }

        this.settings.enabled = !this.settings.enabled;
        this.saveSettings();
        return { success: true, enabled: this.settings.enabled };
    }

    // Update settings
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
        this.saveSettings();
    }

    // Get current settings
    getSettings() {
        return { ...this.settings };
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProfanityFilter;
} else if (typeof window !== 'undefined') {
    window.ProfanityFilter = ProfanityFilter;
}
