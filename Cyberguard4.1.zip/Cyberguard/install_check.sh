#!/bin/bash

# Cyber Guard Pro - Quick Installation Script
# This script helps verify the extension is ready for loading

echo "🔒 Cyber Guard Pro - Installation Verification"
echo "=============================================="

# Check if we're in the right directory
if [ ! -f "manifest.json" ]; then
    echo "❌ Error: manifest.json not found. Please run this script from the Cyberguard directory."
    exit 1
fi

echo "✅ Found manifest.json"

# Check required files
required_files=("background.js" "content.js" "popup.html" "popup.js" "popup.css" "dashboard.html" "dashboard.js" "dashboard.css" "achievements.json")

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ Found $file"
    else
        echo "❌ Missing $file"
        exit 1
    fi
done

# Check icons directory
if [ -d "icons" ]; then
    echo "✅ Found icons directory"
    
    # Check icon files
    icon_files=("icon16.png" "icon48.png" "icon128.png")
    for icon in "${icon_files[@]}"; do
        if [ -f "icons/$icon" ]; then
            echo "✅ Found icons/$icon"
        else
            echo "❌ Missing icons/$icon"
            exit 1
        fi
    done
else
    echo "❌ Missing icons directory"
    exit 1
fi

# Validate manifest.json
echo ""
echo "📋 Checking manifest.json..."
if command -v jq &> /dev/null; then
    jq . manifest.json > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "✅ manifest.json is valid JSON"
    else
        echo "❌ manifest.json has syntax errors"
        exit 1
    fi
else
    echo "ℹ️  jq not found, skipping JSON validation"
fi

echo ""
echo "🎉 All files verified! Extension is ready for installation."
echo ""
echo "📖 Installation Instructions:"
echo "1. Open Chrome and go to chrome://extensions/"
echo "2. Enable 'Developer mode' (toggle in top-right)"
echo "3. Click 'Load unpacked'"
echo "4. Select this folder: $(pwd)"
echo "5. The extension should appear in your toolbar"
echo ""
echo "📚 For detailed testing instructions, see TESTING_GUIDE.md"
echo "🚀 For deployment information, see DEPLOYMENT_CHECKLIST.md"
echo ""
echo "Happy browsing with Cyber Guard Pro! 🔒"
