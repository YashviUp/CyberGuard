// Cyber Guard Pro - Advanced Background Service Worker
// Enterprise-grade digital wellness and cybersecurity platform

class CyberGuardBackground {
  constructor() {
    this.countingActive = false;
    this.timerId = null;
    this.MAX_DAILY_TIME = 3 * 60 * 60 * 1000; // 3 hours
    this.securityScans = 0;
    this.threatsBlocked = 0;
    this.achievementSystem = new AchievementSystem();
    this.init();
  }

  init() {
    this.setupStorageDefaults();
    this.setupAlarms();
    this.setupMessageListeners();
    this.setupTabListeners();
  }

  setupStorageDefaults() {    chrome.storage.local.get([
      'dailyUsage', 'lastUsageDate', 'browsingHistory', 'achievements',
      'securityStats', 'privacyScore', 'userPreferences', 'threatHistory',
      'parentalControls'
    ], (data) => {
      const defaults = {
        dailyUsage: 0,
        lastUsageDate: new Date().toDateString(),
        browsingHistory: {},
        achievements: [],
        securityStats: {
          scansPerformed: 0,
          threatsBlocked: 0,
          safeDays: 0,
          privacyScore: 85,
          lastScanDate: null
        },
        privacyScore: 85,
        userPreferences: {
          theme: 'auto',
          notifications: true,
          autoScan: true,
          privacyMode: 'balanced'
        },
        threatHistory: [],
        parentalControls: {
          enabled: false,
          pin: null,
          languages: {
            english: true,
            hindi: false,
            spanish: false,
            tamil: false,
            malayalam: false,
            telugu: false
          },
          filterStrength: 'moderate',
          contentBlocked: 0,
          lastBlockedContent: []
        }
      };

      const updates = {};
      Object.keys(defaults).forEach(key => {
        if (data[key] === undefined) {
          updates[key] = defaults[key];
        }
      });

      if (Object.keys(updates).length > 0) {
        chrome.storage.local.set(updates);
      }
    });
  }

  setupAlarms() {
    // Create periodic security scan alarm
    chrome.alarms.create('securityScan', { periodInMinutes: 30 });
    chrome.alarms.create('dailyReset', { when: this.getTomorrowMidnight() });
    chrome.alarms.create('achievementCheck', { periodInMinutes: 5 });
  }

  getTomorrowMidnight() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    return tomorrow.getTime();
  }

  setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
      return true; // Keep message channel open for async response
    });
  }

  setupTabListeners() {
    chrome.tabs.onActivated.addListener(() => {
      this.startCounting();
    });

    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'complete' && tab.url) {
        this.analyzeWebsite(tab.url);
        this.updateBrowsingHistory(tab.url);
      }
    });

    chrome.webNavigation.onCompleted.addListener((details) => {
      if (details.frameId === 0) { // Main frame only
        this.performSecurityScan(details.url, details.tabId);
      }
    });
  }

  async handleMessage(message, sender, sendResponse) {
    try {
      switch (message.type) {
        case 'startCounting':
          this.startCounting();
          sendResponse({ status: 'counting started' });
          break;

        case 'stopCounting':
          this.stopCounting();
          sendResponse({ status: 'counting stopped' });
          break;

        case 'getDashboardData':
          const dashboardData = await this.getDashboardData();
          sendResponse(dashboardData);
          break;

        case 'performSecurityScan':
          const scanResult = await this.performFullSecurityScan();
          sendResponse(scanResult);
          break;

        case 'updateAchievements':
          await this.achievementSystem.checkAchievements(message.data);
          sendResponse({ status: 'achievements updated' });
          break;

        case 'exportData':
          const exportData = await this.exportUserData();
          sendResponse(exportData);
          break;        case 'updateSettings':
          await this.updateUserSettings(message.settings);
          sendResponse({ status: 'settings updated' });
          break;

        case 'updateParentalControls':
          await this.updateParentalControls(message.settings);
          sendResponse({ status: 'parental controls updated' });
          break;

        case 'verifyParentalPin':
          const isValid = await this.verifyParentalPin(message.pin);
          sendResponse({ valid: isValid });
          break;

        case 'logContentIncident':
          await this.logContentIncident(message.incident);
          sendResponse({ status: 'incident logged' });
          break;

        case 'getParentalStats':
          const stats = await this.getParentalStats();
          sendResponse(stats);
          break;

        case 'notifyContentBlocked':
          await this.handleContentBlocked(message.details);
          sendResponse({ status: 'notification sent' });
          break;

        default:
          sendResponse({ error: 'Unknown message type' });
      }
    } catch (error) {
      console.error('Background message handling error:', error);
      sendResponse({ error: error.message });
    }
  }

  startCounting() {
    if (this.countingActive) return;
    this.countingActive = true;
    
    this.timerId = setInterval(() => {
      this.resetDailyUsageIfNeeded();
      this.updateUsageTime();
    }, 1000);
  }

  stopCounting() {
    this.countingActive = false;
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  resetDailyUsageIfNeeded() {
    chrome.storage.local.get(['lastUsageDate'], (data) => {
      const today = new Date().toDateString();
      if (data.lastUsageDate !== today) {
        chrome.storage.local.set({
          dailyUsage: 0,
          lastUsageDate: today,
          browsingHistory: {}
        });
        this.achievementSystem.checkDailyReset();
      }
    });
  }

  updateUsageTime() {
    chrome.storage.local.get(['dailyUsage'], (data) => {
      let newUsage = (data.dailyUsage || 0) + 1000; // increment by 1 second
      chrome.storage.local.set({ dailyUsage: newUsage }, () => {
        if (newUsage >= this.MAX_DAILY_TIME) {
          this.notifyDailyLimit();
        }
      });
    });
  }

  notifyDailyLimit() {
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'showBigPopup',
          reason: 'You have reached your daily browsing limit of 3 hours. Time for a healthy break! 🌟'
        }).catch(() => {
          // Ignore errors for inactive tabs
        });
      }
    });

    // Create system notification
    chrome.notifications.create('dailyLimit', {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Cyber Guard Pro - Daily Limit Reached',
      message: 'You\'ve reached your 3-hour daily browsing goal. Great job maintaining healthy digital habits!'
    });
  }

  async getDashboardData() {
    return new Promise((resolve) => {
      chrome.storage.local.get([
        'dailyUsage', 'browsingHistory', 'achievements', 'securityStats',
        'privacyScore', 'threatHistory', 'userPreferences'
      ], (data) => {
        resolve({
          dailyUsage: data.dailyUsage || 0,
          browsingHistory: data.browsingHistory || {},
          achievements: data.achievements || [],
          securityStats: data.securityStats || {
            scansPerformed: 0,
            threatsBlocked: 0,
            safeDays: 0,
            privacyScore: 85
          },
          privacyScore: data.privacyScore || 85,
          threatHistory: data.threatHistory || [],
          userPreferences: data.userPreferences || {}
        });
      });
    });
  }

  async performFullSecurityScan() {
    try {
      const scanResults = {
        timestamp: new Date().toISOString(),
        threatsFound: 0,
        vulnerabilities: [],
        recommendations: [],
        overallScore: 95
      };

      // Simulate comprehensive security analysis
      const threats = await this.detectThreats();
      const privacy = await this.analyzePrivacy();
      const security = await this.checkSecurityHeaders();

      scanResults.threatsFound = threats.length;
      scanResults.vulnerabilities = [...threats, ...privacy.issues, ...security.issues];
      scanResults.recommendations = this.generateRecommendations(scanResults.vulnerabilities);
      scanResults.overallScore = this.calculateSecurityScore(scanResults);

      // Update statistics
      await this.updateSecurityStats(scanResults);
      
      // Check for achievements
      await this.achievementSystem.checkSecurityAchievements(scanResults);

      return scanResults;
    } catch (error) {
      console.error('Security scan error:', error);
      return {
        error: 'Security scan failed',
        timestamp: new Date().toISOString()
      };
    }
  }

  async detectThreats() {
    // Advanced threat detection simulation
    const threats = [];
    
    // Check for suspicious URLs in browsing history
    const data = await this.getStorageData(['browsingHistory']);
    const history = data.browsingHistory || {};
    
    Object.keys(history).forEach(url => {
      if (this.isSuspiciousUrl(url)) {
        threats.push({
          type: 'suspicious_url',
          url: url,
          risk: 'medium',
          description: 'Potentially unsafe website detected'
        });
      }
    });

    return threats;
  }

  isSuspiciousUrl(url) {
    const suspiciousPatterns = [
      /bit\.ly|tinyurl|short\.link/i,
      /free.*download.*now/i,
      /click.*here.*win/i,
      /urgent.*action.*required/i
    ];
    
    return suspiciousPatterns.some(pattern => pattern.test(url));
  }

  async analyzePrivacy() {
    return {
      score: Math.floor(Math.random() * 20) + 80, // 80-100
      issues: [],
      recommendations: [
        'Enable two-factor authentication',
        'Review privacy settings on social media',
        'Use strong, unique passwords'
      ]
    };
  }

  async checkSecurityHeaders() {
    return {
      score: Math.floor(Math.random() * 15) + 85, // 85-100
      issues: [],
      recommendations: [
        'Keep browser updated',
        'Enable automatic security updates',
        'Review installed extensions'
      ]
    };
  }

  generateRecommendations(vulnerabilities) {
    const recommendations = [
      'Enable automatic browser updates',
      'Use a password manager',
      'Enable two-factor authentication',
      'Review app permissions regularly',
      'Keep your system updated'
    ];
    
    return recommendations.slice(0, 3 + vulnerabilities.length);
  }

  calculateSecurityScore(results) {
    let score = 100;
    score -= results.threatsFound * 10;
    score -= results.vulnerabilities.length * 5;
    return Math.max(score, 50);
  }

  async updateSecurityStats(scanResults) {
    const data = await this.getStorageData(['securityStats']);
    const stats = data.securityStats || {};
    
    stats.scansPerformed = (stats.scansPerformed || 0) + 1;
    stats.threatsBlocked = (stats.threatsBlocked || 0) + scanResults.threatsFound;
    stats.lastScanDate = new Date().toISOString();
    stats.privacyScore = scanResults.overallScore;
    
    await this.setStorageData({ securityStats: stats });
  }

  async analyzeWebsite(url) {
    try {
      const analysis = {
        url: url,
        timestamp: new Date().toISOString(),
        riskLevel: this.assessRiskLevel(url),
        category: this.categorizeWebsite(url)
      };

      // Store analysis for dashboard
      const data = await this.getStorageData(['threatHistory']);
      const history = data.threatHistory || [];
      
      if (analysis.riskLevel === 'high') {
        history.push(analysis);
        // Keep only last 50 entries
        if (history.length > 50) {
          history.splice(0, history.length - 50);
        }
        await this.setStorageData({ threatHistory: history });
      }

    } catch (error) {
      console.error('Website analysis error:', error);
    }
  }

  assessRiskLevel(url) {
    if (this.isSuspiciousUrl(url)) return 'high';
    if (url.startsWith('https://')) return 'low';
    if (url.startsWith('http://')) return 'medium';
    return 'unknown';
  }

  categorizeWebsite(url) {
    const domain = new URL(url).hostname;
    
    if (/social|facebook|twitter|instagram|linkedin/i.test(domain)) return 'social';
    if (/shop|store|buy|cart|amazon|ebay/i.test(domain)) return 'shopping';
    if (/news|blog|article/i.test(domain)) return 'news';
    if (/bank|finance|payment|paypal/i.test(domain)) return 'financial';
    if (/edu|learn|course|tutorial/i.test(domain)) return 'educational';
    
    return 'general';
  }

  updateBrowsingHistory(url) {
    chrome.storage.local.get(['browsingHistory'], (data) => {
      const history = data.browsingHistory || {};
      const domain = new URL(url).hostname;
      history[domain] = (history[domain] || 0) + 1;
      chrome.storage.local.set({ browsingHistory: history });
    });
  }

  async performSecurityScan(url, tabId) {
    try {
      const riskLevel = this.assessRiskLevel(url);
      
      if (riskLevel === 'high') {
        chrome.tabs.sendMessage(tabId, {
          action: 'showBigPopup',
          reason: 'Warning: This website may pose security risks. Proceed with caution! 🛡️'
        }).catch(() => {
          // Ignore errors for inactive tabs
        });
        
        // Update threat statistics
        const data = await this.getStorageData(['securityStats']);
        const stats = data.securityStats || {};
        stats.threatsBlocked = (stats.threatsBlocked || 0) + 1;
        await this.setStorageData({ securityStats: stats });
      }
    } catch (error) {
      console.error('Security scan error:', error);
    }
  }

  async exportUserData() {
    const data = await this.getStorageData([
      'dailyUsage', 'browsingHistory', 'achievements', 'securityStats',
      'privacyScore', 'threatHistory', 'userPreferences'
    ]);

    return {
      exportDate: new Date().toISOString(),
      version: '4.0',
      data: data
    };
  }
  async updateUserSettings(settings) {
    const data = await this.getStorageData(['userPreferences']);
    const preferences = { ...data.userPreferences, ...settings };
    await this.setStorageData({ userPreferences: preferences });
  }

  // Parental Control Methods
  async updateParentalControls(settings) {
    const data = await this.getStorageData(['parentalControls']);
    const currentSettings = data.parentalControls || {};
    
    const updatedSettings = {
      ...currentSettings,
      ...settings,
      lastUpdated: new Date().toISOString()
    };
    
    await this.setStorageData({ parentalControls: updatedSettings });
    
    // Notify all content scripts about the update
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          action: 'updateParentalSettings',
          settings: updatedSettings
        }).catch(() => {
          // Ignore errors for inactive tabs
        });
      });
    });
    
    // Log achievement for enabling parental controls
    if (settings.enabled && !currentSettings.enabled) {
      await this.achievementSystem.checkAchievements({
        type: 'parental_protection_enabled',
        timestamp: Date.now()
      });
    }
  }

  async verifyParentalPin(inputPin) {
    const data = await this.getStorageData(['parentalControls']);
    const parentalControls = data.parentalControls || {};
    
    return parentalControls.pin === inputPin;
  }

  async logContentIncident(incident) {
    const data = await this.getStorageData(['parentalControls']);
    const parentalControls = data.parentalControls || {};
    
    // Create incident record
    const incidentRecord = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      url: incident.url,
      content: incident.content?.substring(0, 100) + '...', // Truncate for storage
      language: incident.language,
      severity: incident.severity,
      action: incident.action, // 'blocked', 'warned', 'bypassed'
      userAgent: incident.userAgent || 'unknown'
    };
    
    // Update statistics
    const updatedControls = {
      ...parentalControls,
      contentBlocked: (parentalControls.contentBlocked || 0) + 1,
      lastBlockedContent: [
        incidentRecord,
        ...(parentalControls.lastBlockedContent || []).slice(0, 9) // Keep last 10
      ]
    };
    
    await this.setStorageData({ parentalControls: updatedControls });
    
    // Check for achievements
    await this.achievementSystem.checkAchievements({
      type: 'content_blocked',
      count: updatedControls.contentBlocked,
      timestamp: Date.now()
    });
    
    // Send notification to parent/admin if configured
    await this.sendParentalNotification(incidentRecord);
  }

  async getParentalStats() {
    const data = await this.getStorageData(['parentalControls']);
    const parentalControls = data.parentalControls || {};
    
    const today = new Date().toDateString();
    const recentIncidents = (parentalControls.lastBlockedContent || [])
      .filter(incident => new Date(incident.timestamp).toDateString() === today);
    
    return {
      enabled: parentalControls.enabled || false,
      contentBlocked: parentalControls.contentBlocked || 0,
      todayBlocked: recentIncidents.length,
      lastIncident: parentalControls.lastBlockedContent?.[0] || null,
      activeLanguages: Object.keys(parentalControls.languages || {})
        .filter(lang => parentalControls.languages[lang]),
      filterStrength: parentalControls.filterStrength || 'moderate'
    };
  }

  async handleContentBlocked(details) {
    // Create desktop notification
    chrome.notifications.create(`content_blocked_${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Cyber Guard Pro - Content Blocked',
      message: `Inappropriate content detected and blocked on ${new URL(details.url).hostname}`
    });
    
    // Log the incident
    await this.logContentIncident(details);
  }

  async sendParentalNotification(incident) {
    // Create a detailed notification for parents/administrators
    const notification = {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Cyber Guard Pro - Parental Alert',
      message: `Content blocked on ${new URL(incident.url).hostname} at ${new Date(incident.timestamp).toLocaleTimeString()}`
    };
    
    chrome.notifications.create(`parental_alert_${incident.id}`, notification);
  }

  // Utility methods
  getStorageData(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }

  setStorageData(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set(data, resolve);
    });
  }
}

// Achievement System
class AchievementSystem {
  constructor() {
    this.achievements = {
      'first_scan': {
        id: 'first_scan',
        name: 'Security Rookie',
        description: 'Performed your first security scan',
        icon: '🛡️',
        points: 50,
        unlocked: false
      },
      'daily_goal': {
        id: 'daily_goal',
        name: 'Time Manager',
        description: 'Stayed within daily browsing limit',
        icon: '⏰',
        points: 100,
        unlocked: false
      },
      'threat_hunter': {
        id: 'threat_hunter',
        name: 'Threat Hunter',
        description: 'Blocked 10 security threats',
        icon: '🎯',
        points: 200,
        unlocked: false
      },
      'privacy_guardian': {
        id: 'privacy_guardian',
        name: 'Privacy Guardian',
        description: 'Maintained 90+ privacy score for 7 days',
        icon: '🔒',
        points: 300,
        unlocked: false
      },      'cyber_expert': {
        id: 'cyber_expert',
        name: 'Cyber Expert',
        description: 'Completed 100 security scans',
        icon: '👨‍💻',
        points: 500,
        unlocked: false
      },
      'parental_guardian': {
        id: 'parental_guardian',
        name: 'Parental Guardian',
        description: 'Enabled parental controls for family safety',
        icon: '👨‍👩‍👧‍👦',
        points: 150,
        unlocked: false
      },
      'content_protector': {
        id: 'content_protector',
        name: 'Content Protector',
        description: 'Blocked 25 inappropriate content instances',
        icon: '🛡️',
        points: 200,
        unlocked: false
      },
      'vigilant_guardian': {
        id: 'vigilant_guardian',
        name: 'Vigilant Guardian',
        description: 'Blocked 100 inappropriate content instances',
        icon: '👁️',
        points: 400,
        unlocked: false
      },
      'multilingual_protector': {
        id: 'multilingual_protector',
        name: 'Multilingual Protector',
        description: 'Enabled content filtering for 3+ languages',
        icon: '🌍',
        points: 250,
        unlocked: false
      }
    };
  }

  async checkAchievements(data) {
    const achievements = await this.getUnlockedAchievements();
    const newUnlocks = [];

    // Check each achievement
    for (const [id, achievement] of Object.entries(this.achievements)) {
      if (!achievements.includes(id)) {
        if (await this.checkAchievementCondition(id, data)) {
          newUnlocks.push(achievement);
          achievements.push(id);
        }
      }
    }

    if (newUnlocks.length > 0) {
      await this.setStorageData({ achievements: achievements });
      this.notifyAchievements(newUnlocks);
    }

    return newUnlocks;
  }
  async checkAchievementCondition(achievementId, data) {
    switch (achievementId) {
      case 'first_scan':
        return data.securityStats?.scansPerformed >= 1;
      
      case 'daily_goal':
        return data.dailyUsage < 3 * 60 * 60 * 1000; // Under 3 hours
      
      case 'threat_hunter':
        return data.securityStats?.threatsBlocked >= 10;
      
      case 'privacy_guardian':
        return data.privacyScore >= 90;
      
      case 'cyber_expert':
        return data.securityStats?.scansPerformed >= 100;
      
      case 'parental_guardian':
        return data.type === 'parental_protection_enabled';
      
      case 'content_protector':
        return data.count >= 25;
      
      case 'vigilant_guardian':
        return data.count >= 100;
      
      case 'multilingual_protector': {
        // Check if 3 or more languages are enabled
        const parentalData = await cyberGuard.getStorageData(['parentalControls']);
        const languages = parentalData.parentalControls?.languages || {};
        const enabledCount = Object.values(languages).filter(enabled => enabled).length;
        return enabledCount >= 3;
      }
      
      default:
        return false;
    }
  }

  async getUnlockedAchievements() {
    const data = await this.getStorageData(['achievements']);
    return data.achievements || [];
  }

  notifyAchievements(achievements) {
    achievements.forEach(achievement => {
      chrome.notifications.create(`achievement_${achievement.id}`, {
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: `🎉 Achievement Unlocked!`,
        message: `${achievement.icon} ${achievement.name}\n${achievement.description}\n+${achievement.points} points`
      });
    });
  }

  async checkSecurityAchievements(scanResults) {
    const data = await cyberGuard.getDashboardData();
    await this.checkAchievements(data);
  }

  async checkDailyReset() {
    const data = await cyberGuard.getDashboardData();
    await this.checkAchievements(data);
  }

  // Utility methods
  getStorageData(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }

  setStorageData(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set(data, resolve);
    });
  }
}

// Initialize background service
const cyberGuard = new CyberGuardBackground();

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  switch (alarm.name) {
    case 'securityScan':
      cyberGuard.performFullSecurityScan();
      break;
    
    case 'dailyReset':
      cyberGuard.resetDailyUsageIfNeeded();
      chrome.alarms.create('dailyReset', { when: cyberGuard.getTomorrowMidnight() });
      break;
    
    case 'achievementCheck':
      cyberGuard.achievementSystem.checkAchievements();
      break;
  }
});

// Handle installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.notifications.create('welcome', {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Welcome to Cyber Guard Pro!',
      message: 'Your digital wellness and security companion is now active. Click the extension icon to get started!'
    });
  }
});
