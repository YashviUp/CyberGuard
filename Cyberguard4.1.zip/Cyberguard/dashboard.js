// Cyber Guard Pro - Enhanced Dashboard JavaScript
// Comprehensive analytics, gamification, and management interface

// Safe wrapper for chrome.runtime.sendMessage to handle extension context invalidation
function safeSendMessage(message, callback) {
  try {
    if (chrome.runtime?.id) {
      chrome.runtime.sendMessage(message, callback);
    } else {
      console.log('Extension context invalidated, message not sent:', message);
      if (callback) callback({ error: 'Extension context invalidated' });
    }
  } catch (error) {
    if (error.message.includes('Extension context invalidated')) {
      console.log('Extension context invalidated, dashboard will reload on next navigation');
    } else {
      console.error('Error sending message to background:', error);
    }
    if (callback) callback({ error: error.message });
  }
}

// Dashboard Controller Class
class CyberGuardDashboard {    constructor() {
        this.data = {};
        this.charts = {};
        this.themeManager = new ThemeManager();
        this.profanityFilter = new ProfanityFilter();
        
        this.init();
    }
      async init() {
        // Load parental control settings
        await this.profanityFilter.loadSettings();
        
        this.bindEvents();
        await this.loadData();
        this.setupCharts();
        this.updateUI();
        this.startAutoRefresh();
        
        // Show loading complete
        this.hideLoadingStates();
    }
      bindEvents() {
        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.themeManager.toggleTheme();
            });
        }
        
        // Settings controls
        const timeLimitSlider = document.getElementById('timeLimitSlider');
        if (timeLimitSlider) {
            timeLimitSlider.addEventListener('input', (e) => {
                const hours = parseFloat(e.target.value);
                document.getElementById('timeLimitValue').textContent = hours + ' hours';
            });
        }
        
        const saveSettings = document.getElementById('saveSettings');
        if (saveSettings) {
            saveSettings.addEventListener('click', () => {
                this.saveSettings();
            });
        }
        
        // Action buttons
        const fullSecurityScan = document.getElementById('fullSecurityScan');
        if (fullSecurityScan) {
            fullSecurityScan.addEventListener('click', () => {
                this.performFullSecurityScan();
            });
        }
        
        const exportData = document.getElementById('exportData');
        if (exportData) {
            exportData.addEventListener('click', () => {
                this.exportData();
            });
        }
        
        const helpSupport = document.getElementById('helpSupport');
        if (helpSupport) {
            helpSupport.addEventListener('click', () => {
                this.openHelp();
            });
        }
          // Time filter
        const timeFilter = document.getElementById('timeFilter');
        if (timeFilter) {
            timeFilter.addEventListener('change', (e) => {
                this.updateAnalytics(e.target.value);
            });
        }

        // Parental Control Event Listeners
        this.bindParentalControlEvents();
    }

    bindParentalControlEvents() {
        // Parental control toggle
        const parentalControlEnabled = document.getElementById('parentalControlEnabled');
        if (parentalControlEnabled) {
            parentalControlEnabled.addEventListener('change', (e) => {
                this.toggleParentalControl(e.target.checked);
            });
        }

        // Language filter checkboxes
        ['English', 'Hindi', 'Spanish', 'Tamil', 'Malayalam', 'Telugu'].forEach(lang => {
            const checkbox = document.getElementById(`filter${lang}`);
            if (checkbox) {
                checkbox.addEventListener('change', () => {
                    this.updateLanguageFilters();
                });
            }
        });

        // Filter strength selector
        const filterStrength = document.getElementById('parentalFilterStrength');
        if (filterStrength) {
            filterStrength.addEventListener('change', (e) => {
                this.updateFilterStrength(e.target.value);
            });
        }

        // PIN setup button
        const setupPinButton = document.getElementById('setupParentalPin');
        if (setupPinButton) {
            setupPinButton.addEventListener('click', () => {
                this.showPinSetupDialog();
            });
        }
    }
      async loadData() {
        try {
            this.data = await new Promise((resolve) => {
                safeSendMessage({ type: 'getDashboardData' }, (response) => {
                    if (response && !response.error) {
                        resolve(response);
                    } else {
                        resolve(null);
                    }
                });
            });
            
            if (!this.data) {
                this.data = this.getDefaultData();
            }
        } catch (error) {
            console.error('Failed to load data:', error);
            this.data = this.getDefaultData();
        }
    }
    
    getDefaultData() {
        return {
            dailyUsage: 0,
            browsingHistory: {},
            achievements: { unlocked: [], xp: 0, level: 1, streak: 0 },
            securityStats: {
                threatsBlocked: 0,
                sensitiveDataProtected: 0,
                phishingAttemptsBlocked: 0,
                maliciousSitesBlocked: 0
            },
            userPreferences: {
                dailyLimit: 3 * 60 * 60 * 1000,
                notifications: true,
                contentFiltering: 'standard',
                securityLevel: 'balanced',
                theme: 'auto'
            }
        };
    }
    
    updateUI() {
        this.updateStats();
        this.updateUserProfile();
        this.updateSecurityStatus();
        this.updateSitesList();
        this.updateAchievements();
        this.updatePrivacyInsights();
        this.updateSettings();
    }
    
    updateStats() {
        const stats = this.calculateStats();
        
        // Update stat cards with animations
        this.animateValue('totalTimeToday', stats.timeToday);
        this.animateValue('threatsBlocked', stats.threatsBlocked);
        this.animateValue('achievementCount', stats.achievements);
        this.animateValue('privacyScore', stats.privacyScore + '%');
          // Update additional stats
        const dailyAverageElement = document.getElementById('dailyAverage');
        if (dailyAverageElement) dailyAverageElement.textContent = stats.dailyAverage;
        
        const peakHoursElement = document.getElementById('peakHours');
        if (peakHoursElement) peakHoursElement.textContent = stats.peakHours;
        
        const currentStreakElement = document.getElementById('currentStreak');
        if (currentStreakElement) currentStreakElement.textContent = stats.streak + ' days';
        
        const totalSitesElement = document.getElementById('totalSites');
        if (totalSitesElement) totalSitesElement.textContent = stats.uniqueSites;
    }
    
    calculateStats() {
        const history = this.data.browsingHistory || {};
        const achievements = this.data.achievements || {};
        const security = this.data.securityStats || {};
        
        return {
            timeToday: this.msToHms(this.data.dailyUsage || 0),
            threatsBlocked: security.threatsBlocked || 0,
            achievements: (achievements.unlocked || []).length,
            privacyScore: this.calculatePrivacyScore(),
            dailyAverage: this.msToHms(this.data.dailyUsage || 0),
            peakHours: this.calculatePeakHours(),
            streak: achievements.streak || 0,
            uniqueSites: Object.keys(history).length
        };
    }
    
    calculatePrivacyScore() {
        // Simplified privacy score calculation
        let score = 100;
        const factors = [];
        
        // Check browsing patterns
        const history = this.data.browsingHistory || {};
        const sites = Object.keys(history);
        
        sites.forEach(site => {
            if (site.includes('facebook') || site.includes('google') || site.includes('amazon')) {
                score -= 5;
            }
        });
        
        return Math.max(score, 60);
    }
    
    calculatePeakHours() {
        // Mock peak hours calculation
        const hour = new Date().getHours();
        
        if (hour >= 9 && hour <= 12) return '9-12 AM';
        if (hour >= 14 && hour <= 17) return '2-5 PM';
        if (hour >= 19 && hour <= 22) return '7-10 PM';
        return 'Variable';
    }
      updateUserProfile() {
        const achievements = this.data.achievements || {};
        const level = Math.floor((achievements.xp || 0) / 1000) + 1;
        const userLevelElement = document.getElementById('userLevel');
        if (userLevelElement) userLevelElement.textContent = level;
    }
    
    updateSecurityStatus() {
        const security = this.data.securityStats || {};
        document.getElementById('blockedToday').textContent = security.threatsBlocked || 0;
        document.getElementById('dataProtected').textContent = security.sensitiveDataProtected || 0;
        document.getElementById('totalThreats').textContent = security.threatsBlocked || 0;
    }
    
    updateSitesList() {
        const sitesList = document.getElementById('sitesList');
        const history = this.data.browsingHistory || {};
        
        if (Object.keys(history).length === 0) {
            sitesList.innerHTML = '<div style="color:#aaa; text-align: center; padding: 20px;">No browsing data available for today.</div>';
            return;
        }
        
        // Sort sites by time spent
        const sortedSites = Object.entries(history)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10); // Show top 10 sites
        
        sitesList.innerHTML = sortedSites.map(([domain, timeMs]) => {
            const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=24`;
            return `
                <div class="site-item">
                    <div class="site-info">
                        <img class="site-favicon" src="${favicon}" alt="${domain}" onerror="this.style.display='none'">
                        <span class="site-name">${domain}</span>
                    </div>
                    <div class="site-time">${this.msToHms(timeMs)}</div>
                </div>
            `;
        }).join('');
    }
      updateAchievements() {
        const achievementsGrid = document.getElementById('achievementsGrid');
        const unlocked = this.data.achievements && this.data.achievements.unlocked || [];
        
        const allAchievements = [
            { name: 'First Steps', icon: '👶', description: 'Started using Cyber Guard' },
            { name: 'Time Keeper', icon: '⏰', description: 'Tracked time for 7 days' },
            { name: 'Security Pro', icon: '🛡️', description: 'Blocked 100 threats' },
            { name: 'Privacy Master', icon: '🔐', description: 'Maintained 90% privacy score' },
            { name: 'Streak Warrior', icon: '🔥', description: '30-day usage streak' },
            { name: 'Clean Browser', icon: '✨', description: 'No toxic content for 14 days' }
        ];
        
        achievementsGrid.innerHTML = allAchievements.map(achievement => {
            const isUnlocked = unlocked.some(a => a.title === achievement.name);
            return `
                <div class="achievement-badge ${isUnlocked ? 'unlocked' : ''}">
                    <div class="achievement-icon">${achievement.icon}</div>
                    <div class="achievement-name">${achievement.name}</div>
                </div>
            `;
        }).join('');
    }
    
    updatePrivacyInsights() {
        const privacyScore = this.calculatePrivacyScore();
        document.getElementById('overallPrivacyScore').textContent = privacyScore;
        
        // Update privacy factors based on browsing history
        const history = this.data.browsingHistory || {};
        const sites = Object.keys(history);
        
        const privacyTips = [
            "Use strong, unique passwords for each account",
            "Enable two-factor authentication when available",
            "Regularly review app permissions",
            "Keep your browser and extensions updated",
            "Use private/incognito mode for sensitive browsing"
        ];
        
        document.getElementById('privacyTips').innerHTML = privacyTips
            .slice(0, 3)
            .map(tip => `<li>${tip}</li>`)
            .join('');
    }
    
    updateSettings() {
        const prefs = this.data.userPreferences || {};
        
        // Update time limit slider
        const timeLimitHours = (prefs.dailyLimit || 10800000) / (1000 * 60 * 60);
        document.getElementById('timeLimitSlider').value = timeLimitHours;
        document.getElementById('timeLimitValue').textContent = timeLimitHours + ' hours';
        
        // Update other settings
        document.getElementById('contentFilterLevel').value = prefs.contentFiltering || 'standard';
        document.getElementById('notificationsEnabled').checked = prefs.notifications !== false;
        document.getElementById('securityLevel').value = prefs.securityLevel || 'balanced';
    }
    
    setupCharts() {
        this.setupUsageChart();
    }
      setupUsageChart() {
        const ctx = document.getElementById('usageChart');
        if (!ctx) return;
        
        // Check if Chart.js is available
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js not loaded, displaying fallback chart');
            this.displayFallbackChart(ctx);
            return;
        }
        
        try {
            // Generate mock data for the chart
            const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            const data = [2.5, 3.2, 2.8, 4.1, 3.5, 1.8, 2.2]; // Hours
            
            this.charts.usage = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Hours',
                        data: data,
                        borderColor: '#4a90e2',
                        backgroundColor: 'rgba(74, 144, 226, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 5,
                            ticks: {
                                callback: function(value) {
                                    return value + 'h';
                                }
                            }
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Chart.js error:', error);
            this.displayFallbackChart(ctx);
        }
    }      displayFallbackChart(canvas) {
        const container = canvas.parentElement;
        
        // Get website usage data from browsing history
        const history = this.data.browsingHistory || {};
        const securityStats = this.data.securityStats || {};
        const dailyUsage = this.data.dailyUsage || 0;
        
        // Calculate additional analytics
        const totalSites = Object.keys(history).length;
        const topSites = Object.entries(history)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([domain, visits]) => ({
                domain: domain.replace('www.', ''),
                visits: visits,
                percentage: Math.min((visits / Math.max(...Object.values(history))) * 100, 100),
                category: this.categorizeWebsite(domain)
            }));

        // Generate productivity insights
        const productivityScore = this.calculateProductivityScore(history);
        const weeklyTrend = this.generateWeeklyTrend();
        const hourlyData = this.generateHourlyData();
        
        // Generate category breakdown
        const categoryBreakdown = this.getCategoryBreakdown(history);
        
        // Generate website bars HTML with enhanced features
        const websiteUsageHtml = topSites.length > 0 ? 
            topSites.map((site, index) => {
                const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57'];
                const height = Math.max(site.percentage * 0.8, 20);
                const categoryIcon = this.getCategoryIcon(site.category);
                return `                    <div class="website-bar" style="display: flex; flex-direction: column; align-items: center; gap: 5px; flex: 1; cursor: pointer;" 
                         data-domain="${site.domain}">
                        <div style="
                            width: 28px; 
                            height: ${height}px; 
                            background: linear-gradient(45deg, ${colors[index]}, ${this.lightenColor(colors[index])});
                            border-radius: 6px 6px 0 0;
                            transition: all 0.3s ease;
                            position: relative;
                            overflow: hidden;
                            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                            border: 1px solid rgba(255,255,255,0.3);
                        ">
                            <div style="
                                position: absolute;
                                top: 0;
                                left: 0;
                                width: 100%;
                                height: 100%;
                                background: linear-gradient(45deg, rgba(255,255,255,0.2) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.2) 75%, transparent 75%);
                                background-size: 8px 8px;
                                animation: slidePattern 3s infinite linear;
                            "></div>
                            <div style="
                                position: absolute;
                                top: 2px;
                                left: 50%;
                                transform: translateX(-50%);
                                font-size: 0.8rem;
                                opacity: 0.9;
                            ">${categoryIcon}</div>
                        </div>
                        <span style="font-size: 0.6rem; text-align: center; max-width: 40px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: rgba(255,255,255,0.9);" title="${site.domain}">${site.domain}</span>
                        <div style="display: flex; flex-direction: column; align-items: center; gap: 1px;">
                            <span style="font-size: 0.5rem; opacity: 0.7;">${site.visits} visits</span>
                            <span style="font-size: 0.45rem; opacity: 0.6;">${site.percentage.toFixed(0)}%</span>
                        </div>
                    </div>
                `;
            }).join('') :
            `<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: rgba(255,255,255,0.7); font-size: 0.8rem;">
                <div style="text-align: center;">
                    <div style="font-size: 2rem; margin-bottom: 8px;">📊</div>
                    <div>No browsing data available</div>
                    <div style="font-size: 0.7rem; opacity: 0.6;">Start browsing to see analytics</div>
                </div>
            </div>`;

        // Generate category breakdown HTML
        const categoryHtml = Object.entries(categoryBreakdown).map(([category, count]) => {
            const icon = this.getCategoryIcon(category);
            const percentage = (count / totalSites * 100).toFixed(0);
            return `
                <div style="display: flex; align-items: center; gap: 8px; padding: 4px 8px; background: rgba(255,255,255,0.1); border-radius: 12px; margin: 2px;">
                    <span style="font-size: 0.8rem;">${icon}</span>
                    <span style="font-size: 0.7rem; flex: 1;">${category}</span>
                    <span style="font-size: 0.6rem; opacity: 0.8;">${percentage}%</span>
                </div>
            `;
        }).join('');

        // Generate hourly heatmap
        const hourlyHeatmap = Array.from({length: 24}, (_, i) => {
            const intensity = hourlyData[i] || 0;
            const opacity = Math.max(intensity / 100, 0.1);
            return `
                <div style="
                    width: 8px; 
                    height: 8px; 
                    background: rgba(255,255,255,${opacity}); 
                    border-radius: 1px; 
                    margin: 1px;
                    transition: all 0.2s ease;
                " title="${i}:00 - ${intensity.toFixed(0)}% activity"></div>
            `;
        }).join('');

        // Generate productivity insights
        const productivityInsights = this.generateProductivityInsights(productivityScore, topSites);

        container.innerHTML = `
            <style>
                @keyframes slidePattern {
                    0% { transform: translateX(-8px); }
                    100% { transform: translateX(8px); }
                }
                @keyframes pulse {
                    0%, 100% { opacity: 0.8; }
                    50% { opacity: 1; }
                }
                @keyframes glow {
                    0%, 100% { box-shadow: 0 0 5px rgba(255,255,255,0.3); }
                    50% { box-shadow: 0 0 15px rgba(255,255,255,0.6); }
                }
                @keyframes floatUp {
                    0% { transform: translateY(20px); opacity: 0; }
                    100% { transform: translateY(0); opacity: 1; }
                }
                .chart-tabs {
                    display: flex;
                    gap: 6px;
                    margin-bottom: 16px;
                    padding: 4px;
                    background: rgba(255,255,255,0.1);
                    border-radius: 8px;
                    backdrop-filter: blur(10px);
                }
                .chart-tab {
                    padding: 6px 12px;
                    background: rgba(255,255,255,0.15);
                    border: none;
                    border-radius: 6px;
                    color: white;
                    font-size: 0.7rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    backdrop-filter: blur(5px);
                }
                .chart-tab.active {
                    background: rgba(255,255,255,0.3);
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
                }
                .chart-tab:hover:not(.active) {
                    background: rgba(255,255,255,0.25);
                    transform: translateY(-1px);
                }
                .metric-pill {
                    display: inline-flex;
                    align-items: center;
                    gap: 4px;
                    padding: 2px 8px;
                    background: rgba(255,255,255,0.2);
                    border-radius: 12px;
                    font-size: 0.6rem;
                    backdrop-filter: blur(5px);
                }
                .productivity-indicator {
                    width: 12px;
                    height: 12px;
                    border-radius: 50%;
                    display: inline-block;
                    margin-right: 4px;
                }
                .productivity-high { background: #48bb78; animation: glow 2s infinite; }
                .productivity-medium { background: #ed8936; }
                .productivity-low { background: #f56565; }
            </style>
            <div style="
                display: flex;
                flex-direction: column;
                height: 400px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #667eea 100%);
                border-radius: 16px;
                color: white;
                padding: 20px;
                position: relative;
                overflow: hidden;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                border: 1px solid rgba(255,255,255,0.2);
                animation: floatUp 0.6s ease-out;
            ">
                <!-- Animated Background Elements -->
                <div style="
                    position: absolute;
                    top: -50px;
                    right: -50px;
                    width: 150px;
                    height: 150px;
                    background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%);
                    border-radius: 50%;
                    opacity: 0.5;
                    animation: pulse 4s infinite;
                "></div>
                <div style="
                    position: absolute;
                    bottom: -30px;
                    left: -30px;
                    width: 100px;
                    height: 100px;
                    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
                    border-radius: 50%;
                    opacity: 0.7;
                    animation: pulse 3s infinite 1s;
                "></div>
                
                <!-- Enhanced Header -->
                <div style="
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 16px;
                    position: relative;
                    z-index: 2;
                ">
                    <div>
                        <div style="font-size: 1.2rem; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                            📊 Advanced Analytics Dashboard
                            <div class="productivity-indicator productivity-${productivityScore > 70 ? 'high' : productivityScore > 40 ? 'medium' : 'low'}"></div>
                        </div>
                        <div style="font-size: 0.8rem; opacity: 0.8;">Built-in Intelligence System (Chart.js unavailable)</div>
                        <div style="margin-top: 4px;">
                            <span class="metric-pill">🎯 ${productivityScore}% Productive</span>
                            <span class="metric-pill">⚡ ${Object.keys(history).length} Sites</span>
                            <span class="metric-pill">🕒 ${this.msToHms(dailyUsage)}</span>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 0.7rem; opacity: 0.7;">Live Analytics</div>
                        <div style="font-size: 0.6rem; opacity: 0.6;">${new Date().toLocaleDateString()}</div>
                    </div>
                </div>
                  <!-- Enhanced Chart Tabs -->
                <div class="chart-tabs">
                    <button class="chart-tab active" data-chart="time">
                        📈 <span>Time Trends</span>
                    </button>
                    <button class="chart-tab" data-chart="sites">
                        🌐 <span>Top Sites</span>
                    </button>
                    <button class="chart-tab" data-chart="categories">
                        📂 <span>Categories</span>
                    </button>
                    <button class="chart-tab" data-chart="heatmap">
                        🔥 <span>Activity Map</span>
                    </button>
                    <button class="chart-tab" data-chart="insights">
                        💡 <span>Insights</span>
                    </button>
                </div>
                
                <!-- Time Trends Chart -->
                <div id="timeChart" style="
                    display: flex;
                    align-items: end;
                    justify-content: space-between;
                    height: 120px;
                    margin-bottom: 15px;
                    padding: 0 10px;
                    position: relative;
                ">
                    ${weeklyTrend.map((day, index) => `                        <div class="weekly-trend-bar" style="display: flex; flex-direction: column; align-items: center; gap: 5px; cursor: pointer;" 
                             data-day="${day.label}">
                            <div style="
                                width: 24px; 
                                height: ${day.height}px; 
                                background: linear-gradient(to top, ${day.color}, ${this.lightenColor(day.color)});
                                border-radius: 4px 4px 0 0; 
                                animation: pulse 2s infinite ${index * 0.2}s;
                                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                                border: 1px solid rgba(255,255,255,0.3);
                                position: relative;
                                overflow: hidden;
                            ">
                                <div style="
                                    position: absolute;
                                    top: 0;
                                    left: 0;
                                    width: 100%;
                                    height: 100%;
                                    background: linear-gradient(45deg, rgba(255,255,255,0.2) 25%, transparent 25%);
                                    background-size: 6px 6px;
                                    animation: slidePattern 2s infinite linear;
                                "></div>
                            </div>
                            <span style="font-size: 0.65rem; font-weight: 600;">${day.label}</span>
                            <span style="font-size: 0.5rem; opacity: 0.7;">${day.hours}h</span>
                        </div>
                    `).join('')}
                </div>
                
                <!-- Website Usage Chart -->
                <div id="sitesChart" style="
                    display: none;
                    height: 120px;
                    margin-bottom: 15px;
                    padding: 0 10px;
                ">
                    <div style="
                        display: flex;
                        align-items: end;
                        justify-content: space-around;
                        height: 100px;
                        gap: 8px;
                    ">
                        ${websiteUsageHtml}
                    </div>
                </div>
                
                <!-- Category Breakdown Chart -->
                <div id="categoriesChart" style="
                    display: none;
                    height: 120px;
                    margin-bottom: 15px;
                    padding: 10px;
                ">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 8px; height: 100%;">
                        ${categoryHtml || '<div style="color: rgba(255,255,255,0.7); text-align: center;">No category data available</div>'}
                    </div>
                </div>
                
                <!-- Hourly Heatmap -->
                <div id="heatmapChart" style="
                    display: none;
                    height: 120px;
                    margin-bottom: 15px;
                    padding: 10px;
                ">
                    <div style="margin-bottom: 8px; font-size: 0.8rem; font-weight: 600;">24-Hour Activity Heatmap</div>
                    <div style="
                        display: grid;
                        grid-template-columns: repeat(12, 1fr);
                        gap: 2px;
                        margin-bottom: 8px;
                    ">
                        ${hourlyHeatmap}
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.6rem; opacity: 0.7;">
                        <span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>11 PM</span>
                    </div>
                </div>
                
                <!-- Productivity Insights -->
                <div id="insightsChart" style="
                    display: none;
                    height: 120px;
                    margin-bottom: 15px;
                    padding: 10px;
                    overflow-y: auto;
                ">
                    <div style="font-size: 0.8rem; font-weight: 600; margin-bottom: 8px;">🧠 AI-Powered Insights</div>
                    ${productivityInsights.map(insight => `
                        <div style="
                            margin-bottom: 6px;
                            padding: 6px 8px;
                            background: rgba(255,255,255,0.1);
                            border-radius: 6px;
                            font-size: 0.7rem;
                            border-left: 3px solid ${insight.color};
                        ">
                            <span style="margin-right: 4px;">${insight.icon}</span>
                            ${insight.text}
                        </div>
                    `).join('')}
                </div>
                
                <!-- Enhanced Stats Row -->
                <div style="
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 12px;
                    margin-top: auto;
                    padding-top: 15px;
                    border-top: 1px solid rgba(255,255,255,0.3);
                ">
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 700;">${this.msToHms(dailyUsage)}</div>
                        <div style="font-size: 0.65rem; opacity: 0.8;">Today's Time</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 700;">${totalSites}</div>
                        <div style="font-size: 0.65rem; opacity: 0.8;">Unique Sites</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 700;">${this.calculatePeakHours()}</div>
                        <div style="font-size: 0.65rem; opacity: 0.8;">Peak Hours</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 700;">${(securityStats.threatsBlocked || 0)}</div>
                        <div style="font-size: 0.65rem; opacity: 0.8;">Threats Blocked</div>
                    </div>
                </div>
            </div>        `;
        
        // Enhanced tab switching functionality with proper event listeners
        setTimeout(() => {
            const tabs = container.querySelectorAll('.chart-tab');
            const websiteBars = container.querySelectorAll('.website-bar');
            const weeklyTrendBars = container.querySelectorAll('.weekly-trend-bar');
            
            // Add click listeners to tabs
            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    e.preventDefault();
                    const chartType = tab.getAttribute('data-chart');
                    this.switchFallbackChart(chartType, container);
                });
            });
            
            // Add hover effects to website bars
            websiteBars.forEach(bar => {
                bar.addEventListener('mouseenter', () => {
                    bar.style.transform = 'scale(1.05)';
                });
                bar.addEventListener('mouseleave', () => {
                    bar.style.transform = 'scale(1)';
                });
            });
            
            // Add hover effects to weekly trend bars
            weeklyTrendBars.forEach(bar => {
                bar.addEventListener('mouseenter', () => {
                    bar.style.transform = 'scale(1.1)';
                });
                bar.addEventListener('mouseleave', () => {
                    bar.style.transform = 'scale(1)';
                });
            });
        }, 0);
    }
    
    switchFallbackChart(type, container) {
        const charts = ['timeChart', 'sitesChart', 'categoriesChart', 'heatmapChart', 'insightsChart'];
        const tabs = container.querySelectorAll('.chart-tab');
        
        // Hide all charts
        charts.forEach(chartId => {
            const chart = container.querySelector(`#${chartId}`);
            if (chart) chart.style.display = 'none';
        });
        
        // Remove active class from all tabs
        tabs.forEach(tab => tab.classList.remove('active'));
        
        // Show selected chart and activate tab
        const chartMap = {
            'time': { chart: 'timeChart', tab: 0 },
            'sites': { chart: 'sitesChart', tab: 1 },
            'categories': { chart: 'categoriesChart', tab: 2 },
            'heatmap': { chart: 'heatmapChart', tab: 3 },
            'insights': { chart: 'insightsChart', tab: 4 }
        };
        
        const selected = chartMap[type];
        if (selected) {
            const selectedChart = container.querySelector(`#${selected.chart}`);
            if (selectedChart) {
                selectedChart.style.display = selected.chart === 'timeChart' ? 'flex' : 'block';
            }
            tabs[selected.tab].classList.add('active');
        }
    }
    
    async saveSettings() {
        const button = document.getElementById('saveSettings');
        const originalText = button.querySelector('.btn-text').textContent;
        
        button.querySelector('.btn-text').textContent = 'Saving...';
        button.disabled = true;
        
        try {
            const preferences = {
                dailyLimit: parseFloat(document.getElementById('timeLimitSlider').value) * 60 * 60 * 1000,
                contentFiltering: document.getElementById('contentFilterLevel').value,
                notifications: document.getElementById('notificationsEnabled').checked,
                securityLevel: document.getElementById('securityLevel').value
            };
            
            await new Promise((resolve) => {
                chrome.runtime.sendMessage({
                    type: 'updatePreferences',
                    preferences: preferences
                }, resolve);
            });
            
            this.showNotification('Settings saved successfully!', 'success');
            
        } catch (error) {
            console.error('Failed to save settings:', error);
            this.showNotification('Failed to save settings', 'error');
        } finally {
            button.querySelector('.btn-text').textContent = originalText;
            button.disabled = false;
        }
    }
    
    async performFullSecurityScan() {
        const button = document.getElementById('fullSecurityScan');
        const originalText = button.querySelector('.btn-text').textContent;
        
        button.querySelector('.btn-text').textContent = 'Scanning...';
        button.querySelector('.btn-icon').textContent = '🔄';
        button.disabled = true;
        
        try {
            // Simulate comprehensive security scan
            await this.simulateSecurityScan();
            
            button.querySelector('.btn-text').textContent = 'Scan Complete!';
            button.querySelector('.btn-icon').textContent = '✅';
            
            this.showNotification('Security scan completed successfully!', 'success');
            
            // Award achievement
            chrome.runtime.sendMessage({
                type: 'unlockAchievement',
                achievementType: 'SECURITY_AWARE',
                title: 'Full Security Scan',
                xpReward: 100,
                message: 'Performed a comprehensive security scan!'
            });
            
        } catch (error) {
            console.error('Security scan failed:', error);
            button.querySelector('.btn-text').textContent = 'Scan Failed';
            button.querySelector('.btn-icon').textContent = '❌';
            this.showNotification('Security scan failed', 'error');
        } finally {
            setTimeout(() => {
                button.querySelector('.btn-text').textContent = originalText;
                button.querySelector('.btn-icon').textContent = '🔍';
                button.disabled = false;
            }, 3000);
        }
    }
    
    async simulateSecurityScan() {
        // Simulate various security checks
        const checks = [
            'Checking for malware...',
            'Scanning browser extensions...',
            'Verifying website certificates...',
            'Analyzing browsing patterns...',
            'Checking for data leaks...',
            'Validating security settings...'
        ];
        
        for (const check of checks) {
            await new Promise(resolve => setTimeout(resolve, 500));
            console.log(check);
        }
    }
    
    exportData() {
        try {
            const exportData = {
                version: '4.0',
                exportDate: new Date().toISOString(),
                dailyUsage: this.data.dailyUsage,
                browsingHistory: this.data.browsingHistory,
                achievements: this.data.achievements,
                securityStats: this.data.securityStats,
                userPreferences: this.data.userPreferences
            };
            
            const blob = new Blob([JSON.stringify(exportData, null, 2)], {
                type: 'application/json'
            });
            
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `cyberguard-data-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Data exported successfully!', 'success');
            
        } catch (error) {
            console.error('Export failed:', error);
            this.showNotification('Failed to export data', 'error');
        }
    }
    
    openHelp() {
        const helpContent = `
            <h3>Dashboard Features:</h3>
            <ul>
                <li><strong>Usage Analytics:</strong> Track your daily browsing time and patterns</li>
                <li><strong>Security Status:</strong> Monitor threats blocked and security metrics</li>
                <li><strong>Achievements:</strong> Earn XP and unlock badges for good digital habits</li>
                <li><strong>Privacy Insights:</strong> Understand your privacy score and get tips</li>
                <li><strong>Settings:</strong> Customize time limits, security levels and preferences</li>
            </ul>
            <p>Need more help? Visit our support page or contact us at support@cyberguardpro.com</p>
        `;
        
        this.showModal('Help & Support', helpContent);
    }
    
    updateAnalytics(timeframe) {
        // Update charts based on selected timeframe
        if (this.charts.usage) {
            let labels, data;
            
            switch (timeframe) {
                case 'today':
                    labels = Array.from({length: 24}, (_, i) => i + ':00');
                    data = Array.from({length: 24}, () => Math.random() * 0.5);
                    break;
                case 'week':
                    labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    data = [2.5, 3.2, 2.8, 4.1, 3.5, 1.8, 2.2];
                    break;
                case 'month':
                    labels = Array.from({length: 30}, (_, i) => (i + 1).toString());
                    data = Array.from({length: 30}, () => Math.random() * 5);
                    break;
            }
            
            this.charts.usage.data.labels = labels;
            this.charts.usage.data.datasets[0].data = data;
            this.charts.usage.update();
        }
    }
    
    // Utility functions
    msToHms(duration) {
        const seconds = Math.floor((duration / 1000) % 60);
        const minutes = Math.floor((duration / (1000 * 60)) % 60);
        const hours = Math.floor((duration / (1000 * 60 * 60)));
        
        return `${hours}h ${minutes}m ${seconds}s`;
    }
    
    animateValue(elementId, targetValue) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        element.textContent = targetValue;
        element.style.animation = 'slideIn 0.5s ease-out';
    }
    
    showNotification(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-icon">
                ${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}
            </div>
            <div class="notification-message">${message}</div>
            <button class="notification-close">×</button>
        `;
        
        notification.style.cssText = `
            background: ${type === 'success' ? '#48bb78' : type === 'error' ? '#f56565' : '#4a90e2'};
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease-out;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        `;
        
        container.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
        
        // Manual close
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
    }
    
    showModal(title, content) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        `;
        
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        `;
        
        const modalContent = modal.querySelector('.modal-content');
        modalContent.style.cssText = `
            background: white;
            border-radius: 12px;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        `;
        
        const modalHeader = modal.querySelector('.modal-header');
        modalHeader.style.cssText = `
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        `;
        
        const modalBody = modal.querySelector('.modal-body');
        modalBody.style.cssText = `
            padding: 24px;
            line-height: 1.6;
        `;
        
        document.body.appendChild(modal);
        
        // Close modal handlers
        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    hideLoadingStates() {
        document.querySelectorAll('.sites-loading, .chart-loading').forEach(el => {
            el.style.display = 'none';
        });
    }
      startAutoRefresh() {
        // Refresh data every 30 seconds
        setInterval(async () => {
            await this.loadData();
            this.updateUI();
        }, 30000);
    }
    
    // Helper method to convert milliseconds to hours:minutes:seconds format
    msToHms(ms) {
        const hours = Math.floor(ms / (1000 * 60 * 60));
        const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
        if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else if (minutes > 0) {
            return `${minutes}m`;
        } else {
            return '<1m';
        }
    }
    
    // Helper method to calculate peak hours
    calculatePeakHours() {
        const currentHour = new Date().getHours();
        if (currentHour >= 9 && currentHour <= 17) {
            return '9-17';
        } else if (currentHour >= 18 && currentHour <= 23) {
            return '18-23';
        } else {
            return '0-8';
        }
    }
    
    // Advanced Analytics Helper Methods
    categorizeWebsite(domain) {
        const lowerDomain = domain.toLowerCase();
        
        if (/(facebook|twitter|instagram|linkedin|tiktok|snapchat|discord|reddit|telegram)/i.test(lowerDomain)) return 'social';
        if (/(youtube|netflix|spotify|twitch|hulu|disney|prime)/i.test(lowerDomain)) return 'entertainment';
        if (/(amazon|ebay|shop|store|buy|cart|aliexpress|etsy)/i.test(lowerDomain)) return 'shopping';
        if (/(gmail|outlook|mail|yahoo|protonmail)/i.test(lowerDomain)) return 'communication';
        if (/(github|stackoverflow|developer|code|programming|tech)/i.test(lowerDomain)) return 'development';
        if (/(news|blog|article|medium|reuters|cnn|bbc)/i.test(lowerDomain)) return 'news';
        if (/(bank|finance|payment|paypal|crypto|invest)/i.test(lowerDomain)) return 'financial';
        if (/(edu|learn|course|tutorial|udemy|coursera)/i.test(lowerDomain)) return 'educational';
        if (/(google|bing|search|duckduckgo)/i.test(lowerDomain)) return 'search';
        if (/(cloud|drive|dropbox|onedrive|sync)/i.test(lowerDomain)) return 'productivity';
        
        return 'general';
    }
    
    getCategoryIcon(category) {
        const icons = {
            'social': '👥',
            'entertainment': '🎬',
            'shopping': '🛒',
            'communication': '✉️',
            'development': '💻',
            'news': '📰',
            'financial': '💳',
            'educational': '📚',
            'search': '🔍',
            'productivity': '⚡',
            'general': '🌐'
        };
        return icons[category] || '🌐';
    }
    
    calculateProductivityScore(history) {
        const productiveCategories = ['development', 'educational', 'productivity', 'news'];
        const distractingCategories = ['social', 'entertainment'];
        
        let productiveTime = 0;
        let distractingTime = 0;
        let totalTime = 0;
        
        Object.entries(history).forEach(([domain, visits]) => {
            const category = this.categorizeWebsite(domain);
            if (productiveCategories.includes(category)) {
                productiveTime += visits;
            } else if (distractingCategories.includes(category)) {
                distractingTime += visits;
            }
            totalTime += visits;
        });
        
        if (totalTime === 0) return 75; // Default score
        return Math.round((productiveTime / totalTime) * 100);
    }
    
    generateWeeklyTrend() {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const baseData = [2.5, 3.2, 2.8, 4.1, 3.5, 1.8, 2.2];
        const colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#ff99cc', '#c2c2f0', '#ffb3e6'];
        
        return days.map((day, index) => ({
            label: day,
            height: Math.max(baseData[index] * 20, 30),
            hours: baseData[index].toFixed(1),
            color: colors[index]
        }));
    }
    
    generateHourlyData() {
        // Simulate realistic hourly usage pattern
        const hourlyPattern = [
            5, 3, 2, 1, 1, 2, 15, 35, 55, 75, 85, 90,  // 12AM-11AM
            95, 80, 70, 85, 90, 95, 75, 60, 45, 30, 20, 10  // 12PM-11PM
        ];
        return hourlyPattern;
    }
    
    getCategoryBreakdown(history) {
        const breakdown = {};
        Object.keys(history).forEach(domain => {
            const category = this.categorizeWebsite(domain);
            breakdown[category] = (breakdown[category] || 0) + 1;
        });
        return breakdown;
    }
    
    generateProductivityInsights(score, topSites) {
        const insights = [];
        
        if (score > 70) {
            insights.push({
                icon: '🎯',
                text: 'Excellent productivity! You\'re focused on valuable content.',
                color: '#48bb78'
            });
        } else if (score > 40) {
            insights.push({
                icon: '⚖️',
                text: 'Balanced browsing between productive and leisure activities.',
                color: '#ed8936'
            });
        } else {
            insights.push({
                icon: '📱',
                text: 'Consider reducing time on distracting sites for better focus.',
                color: '#f56565'
            });
        }
        
        if (topSites.length > 0) {
            const topSite = topSites[0];
            insights.push({
                icon: '🏆',
                text: `Most visited: ${topSite.domain} (${topSite.visits} visits)`,
                color: '#4299e1'
            });
        }
        
        const currentHour = new Date().getHours();
        if (currentHour >= 9 && currentHour <= 17) {
            insights.push({
                icon: '💼',
                text: 'Currently in peak productivity hours. Stay focused!',
                color: '#38b2ac'
            });
        } else if (currentHour >= 22 || currentHour <= 6) {
            insights.push({
                icon: '🌙',
                text: 'Late night browsing detected. Consider getting rest.',
                color: '#805ad5'
            });
        }
        
        insights.push({
            icon: '🔒',
            text: `Security shield active - ${Math.floor(Math.random() * 5) + 3} threats blocked today.`,
            color: '#48bb78'
        });
        
        return insights;
    }
      lightenColor(color) {
        // Simple color lightening function
        const colorMap = {
            '#ff6b6b': '#ff8a8a',
            '#4ecdc4': '#6ee6df',
            '#45b7d1': '#65c7e1',
            '#96ceb4': '#a6dec4',
            '#feca57': '#ffd477',
            '#ff9999': '#ffb3b3',
            '#66b3ff': '#80c3ff',
            '#99ff99': '#b3ffb3',
            '#ffcc99': '#ffd9b3',
            '#ff99cc': '#ffb3d9',
            '#c2c2f0': '#d2d2f5',
            '#ffb3e6': '#ffc6eb'
        };
        return colorMap[color] || color;
    }

    // Parental Control Methods
    async toggleParentalControl(enabled) {
        const settings = this.profanityFilter.getSettings();
        
        if (!enabled && settings.pinProtected) {
            // Disabling parental controls requires PIN
            this.showPinVerificationDialog('disable');
            return;
        }

        try {
            this.profanityFilter.updateSettings({ enabled });
            
            // Notify all content scripts
            safeSendMessage({
                type: 'updateParentalSettings',
                settings: this.profanityFilter.getSettings()
            });

            this.updateParentalControlUI();
            this.showNotification(
                enabled ? 'Parental controls enabled' : 'Parental controls disabled',
                'success'
            );
        } catch (error) {
            console.error('Error toggling parental control:', error);
            this.showNotification('Failed to update parental controls', 'error');
        }
    }

    updateLanguageFilters() {
        const languages = [];
        ['english', 'hindi', 'spanish', 'tamil', 'malayalam', 'telugu'].forEach(lang => {
            const checkbox = document.getElementById(`filter${lang.charAt(0).toUpperCase() + lang.slice(1)}`);
            if (checkbox && checkbox.checked) {
                languages.push(lang);
            }
        });

        this.profanityFilter.updateSettings({ languages });
        this.updateContentScripts();
    }

    updateFilterStrength(strength) {
        this.profanityFilter.updateSettings({ strength });
        this.updateContentScripts();
    }

    showPinSetupDialog() {
        const settings = this.profanityFilter.getSettings();
        
        const dialog = document.createElement('div');
        dialog.innerHTML = `
            <div style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.7);
                z-index: 10000;
                display: flex;
                justify-content: center;
                align-items: center;
            ">
                <div style="
                    background: white;
                    padding: 32px;
                    border-radius: 16px;
                    max-width: 400px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                ">
                    <h3 style="margin-bottom: 16px; color: #333;">
                        ${settings.pinProtected ? '🔐 Change PIN' : '🔐 Setup PIN Protection'}
                    </h3>
                    <p style="color: #666; margin-bottom: 20px; line-height: 1.5;">
                        ${settings.pinProtected ? 
                          'Enter your current PIN and then set a new one.' : 
                          'Set a PIN to prevent unauthorized changes to parental controls.'}
                    </p>
                    
                    ${settings.pinProtected ? `
                        <input type="password" id="currentPin" placeholder="Current PIN" 
                               style="width: 100%; padding: 12px; margin-bottom: 12px; border: 2px solid #ddd; 
                                      border-radius: 6px; font-size: 16px; text-align: center;">
                    ` : ''}
                    
                    <input type="password" id="newPin" placeholder="New PIN (6 digits)" 
                           style="width: 100%; padding: 12px; margin-bottom: 12px; border: 2px solid #ddd; 
                                  border-radius: 6px; font-size: 16px; text-align: center;" maxlength="6">
                    
                    <input type="password" id="confirmPin" placeholder="Confirm PIN" 
                           style="width: 100%; padding: 12px; margin-bottom: 20px; border: 2px solid #ddd; 
                                  border-radius: 6px; font-size: 16px; text-align: center;" maxlength="6">
                    
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button id="savePinBtn" style="
                            background: #4a90e2; color: white; border: none; padding: 12px 24px; 
                            border-radius: 6px; cursor: pointer; font-weight: 600;">
                            Save PIN
                        </button>
                        <button id="cancelPinBtn" style="
                            background: #ccc; color: #666; border: none; padding: 12px 24px; 
                            border-radius: 6px; cursor: pointer; font-weight: 600;">
                            Cancel
                        </button>
                        ${settings.pinProtected ? `
                            <button id="removePinBtn" style="
                                background: #ff4444; color: white; border: none; padding: 12px 24px; 
                                border-radius: 6px; cursor: pointer; font-weight: 600;">
                                Remove PIN
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(dialog);

        // Event listeners
        document.getElementById('savePinBtn').addEventListener('click', () => {
            this.handlePinSave(dialog, settings.pinProtected);
        });

        document.getElementById('cancelPinBtn').addEventListener('click', () => {
            dialog.remove();
        });

        if (settings.pinProtected) {
            document.getElementById('removePinBtn').addEventListener('click', () => {
                this.handlePinRemoval(dialog);
            });
        }

        // Auto-focus first input
        const firstInput = settings.pinProtected ? 
            document.getElementById('currentPin') : 
            document.getElementById('newPin');
        firstInput.focus();
    }

    handlePinSave(dialog, hasExistingPin) {
        const currentPin = hasExistingPin ? document.getElementById('currentPin').value : null;
        const newPin = document.getElementById('newPin').value;
        const confirmPin = document.getElementById('confirmPin').value;

        // Validation
        if (hasExistingPin && !this.profanityFilter.validatePin(currentPin)) {
            this.showError('Current PIN is incorrect');
            return;
        }

        if (newPin.length !== 6 || !/^\d{6}$/.test(newPin)) {
            this.showError('PIN must be exactly 6 digits');
            return;
        }

        if (newPin !== confirmPin) {
            this.showError('PINs do not match');
            return;
        }

        // Save PIN
        this.profanityFilter.setPin(newPin);
        this.updateParentalControlUI();
        dialog.remove();
        this.showNotification('PIN saved successfully', 'success');
    }

    handlePinRemoval(dialog) {
        const currentPin = document.getElementById('currentPin').value;
        
        if (!this.profanityFilter.validatePin(currentPin)) {
            this.showError('Current PIN is incorrect');
            return;
        }

        this.profanityFilter.removePin();
        this.updateParentalControlUI();
        dialog.remove();
        this.showNotification('PIN protection removed', 'success');
    }

    showPinVerificationDialog(action) {
        const dialog = document.createElement('div');
        dialog.innerHTML = `
            <div style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.7);
                z-index: 10000;
                display: flex;
                justify-content: center;
                align-items: center;
            ">
                <div style="
                    background: white;
                    padding: 32px;
                    border-radius: 16px;
                    max-width: 300px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                ">
                    <h3 style="margin-bottom: 16px; color: #333;">🔐 Enter PIN</h3>
                    <p style="color: #666; margin-bottom: 20px;">
                        Enter your PIN to ${action} parental controls.
                    </p>
                    
                    <input type="password" id="verifyPin" placeholder="Enter PIN" 
                           style="width: 100%; padding: 12px; margin-bottom: 20px; border: 2px solid #ddd; 
                                  border-radius: 6px; font-size: 16px; text-align: center;" maxlength="6">
                    
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button id="verifyPinBtn" style="
                            background: #4a90e2; color: white; border: none; padding: 12px 24px; 
                            border-radius: 6px; cursor: pointer; font-weight: 600;">
                            Verify
                        </button>
                        <button id="cancelVerifyBtn" style="
                            background: #ccc; color: #666; border: none; padding: 12px 24px; 
                            border-radius: 6px; cursor: pointer; font-weight: 600;">
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(dialog);

        document.getElementById('verifyPinBtn').addEventListener('click', () => {
            const pin = document.getElementById('verifyPin').value;
            if (this.profanityFilter.validatePin(pin)) {
                if (action === 'disable') {
                    this.profanityFilter.updateSettings({ enabled: false });
                    document.getElementById('parentalControlEnabled').checked = false;
                }
                this.updateParentalControlUI();
                dialog.remove();
                this.showNotification(`Parental controls ${action}d`, 'success');
            } else {
                this.showError('Incorrect PIN');
                document.getElementById('verifyPin').value = '';
            }
        });

        document.getElementById('cancelVerifyBtn').addEventListener('click', () => {
            // Reset checkbox if canceling disable
            if (action === 'disable') {
                document.getElementById('parentalControlEnabled').checked = true;
            }
            dialog.remove();
        });

        document.getElementById('verifyPin').focus();
    }

    updateParentalControlUI() {
        const settings = this.profanityFilter.getSettings();
        
        // Update main toggle
        const enabledCheckbox = document.getElementById('parentalControlEnabled');
        if (enabledCheckbox) {
            enabledCheckbox.checked = settings.enabled;
        }

        // Update language checkboxes
        settings.languages.forEach(lang => {
            const checkbox = document.getElementById(`filter${lang.charAt(0).toUpperCase() + lang.slice(1)}`);
            if (checkbox) {
                checkbox.checked = true;
            }
        });

        // Update filter strength
        const strengthSelect = document.getElementById('parentalFilterStrength');
        if (strengthSelect) {
            strengthSelect.value = settings.strength;
        }

        // Update PIN status
        const pinStatus = document.getElementById('pinStatus');
        if (pinStatus) {
            pinStatus.innerHTML = settings.pinProtected ? 
                '<span class="pin-indicator">🔐</span><span>PIN Protected</span>' :
                '<span class="pin-indicator">🔓</span><span>No PIN set</span>';
        }

        // Show/hide details based on enabled state
        const details = document.getElementById('parentalControlDetails');
        if (details) {
            details.style.display = settings.enabled ? 'block' : 'none';
        }
    }

    async updateContentScripts() {
        const settings = this.profanityFilter.getSettings();
        
        try {
            safeSendMessage({
                type: 'updateParentalSettings',
                settings: settings
            });
        } catch (error) {
            console.error('Error updating content scripts:', error);
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#48bb78' : type === 'error' ? '#f56565' : '#4a90e2'};
            color: white;
            padding: 16px 20px;
            border-radius: 8px;
            z-index: 10001;
            animation: slideIn 0.3s ease-out;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    showError(message) {
        this.showNotification(message, 'error');
    }
}

// Theme Manager Class
class ThemeManager {
    constructor() {
        this.currentTheme = localStorage.getItem('cyberguard-theme') || 'auto';
        this.applyTheme();
    }
    
    applyTheme() {
        const body = document.body;
        
        if (this.currentTheme === 'dark') {
            body.classList.add('dark-theme');
        } else if (this.currentTheme === 'light') {
            body.classList.remove('dark-theme');
        } else {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            body.classList.toggle('dark-theme', prefersDark);
        }
        
        // Update theme toggle icon
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icons = { light: '☀️', dark: '🌙', auto: '🌓' };
            themeToggle.querySelector('.theme-icon').textContent = icons[this.currentTheme];
        }
    }
    
    toggleTheme() {
        const themes = ['light', 'dark', 'auto'];
        const currentIndex = themes.indexOf(this.currentTheme);
        this.currentTheme = themes[(currentIndex + 1) % themes.length];
        
        localStorage.setItem('cyberguard-theme', this.currentTheme);
        this.applyTheme();
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new CyberGuardDashboard();
    
    // Add entrance animation
    document.querySelector('.dashboard-container').style.animation = 'slideIn 0.8s ease-out';
    
    console.log('Cyber Guard Pro Dashboard loaded successfully');
});

// Handle window resize for responsive charts
window.addEventListener('resize', () => {
    const charts = window.dashboard && window.dashboard.charts || {};
    Object.values(charts).forEach(chart => {
        if (chart && chart.resize) {
            chart.resize();
        }
    });
});
