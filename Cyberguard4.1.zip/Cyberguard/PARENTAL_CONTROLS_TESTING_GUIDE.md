# Cyber Guard Pro - Parental Controls Testing Guide

## Testing Overview
This guide provides comprehensive testing procedures for the parental control system implemented in Cyber Guard Pro.

## Prerequisites
1. Extension loaded in Chrome (Developer mode)
2. Dashboard accessible via extension popup
3. Test websites with various content types

## Test Scenarios

### 1. Enable Parental Controls
**Steps:**
1. Open Cyber Guard Pro dashboard
2. Navigate to "Parental Controls" section
3. Click "Set Up Parental Controls"
4. Enter a 4-6 digit PIN (e.g., 1234)
5. Confirm PIN
6. Toggle "Enable Parental Controls" to ON
7. Select languages to filter (English, Hindi, Spanish, Tamil, Malayalam, Telugu)
8. Choose filter strength (Mild, Moderate, Strict)
9. Click "Save Settings"

**Expected Result:**
- PIN is saved securely
- Parental controls are enabled
- Settings are synchronized across all tabs
- Success notification appears

### 2. Content Detection and Blocking
**Steps:**
1. Navigate to websites with inappropriate content
2. Try typing bad words in text fields
3. Test in different languages (based on enabled filters)
4. Check various content types: text, comments, social media

**Test Content Examples:**
- English: "This is fucking stupid"
- Hindi: "Ye chutiya website hai"
- Spanish: "Esto es una mierda"
- Tamil: "Antha pundai paithiyam"

**Expected Result:**
- Content warning overlay appears
- Inappropriate content is blurred
- Incident is logged in background
- Desktop notification about blocked content
- Statistics updated in dashboard

### 3. PIN Override System
**Steps:**
1. When content warning appears
2. Click "Enter PIN to Continue"
3. Try entering wrong PIN first
4. Then enter correct PIN

**Expected Result:**
- PIN prompt appears
- Wrong PIN shows error message
- Correct PIN removes warnings and unblurs content
- Bypass incident is logged

### 4. Settings Synchronization
**Steps:**
1. Open multiple tabs with inappropriate content
2. Change parental control settings in dashboard
3. Toggle different languages on/off
4. Change filter strength

**Expected Result:**
- All open tabs receive updated settings
- Content filtering updates in real-time
- No need to refresh pages

### 5. Statistics and Logging
**Steps:**
1. Block various types of content
2. Check dashboard statistics
3. Verify incident logging

**Expected Result:**
- Content blocked counter increases
- Today's blocked count updates
- Recent incidents are logged
- Language breakdown is accurate

### 6. Achievement System
**Steps:**
1. Enable parental controls (Parental Guardian achievement)
2. Block 25+ content instances (Content Protector achievement)
3. Block 100+ content instances (Vigilant Guardian achievement)
4. Enable 3+ languages (Multilingual Protector achievement)

**Expected Result:**
- Achievement notifications appear
- Points are awarded
- Achievement status updates in dashboard

### 7. Disable Parental Controls
**Steps:**
1. Go to parental controls settings
2. Click "Change PIN" or "Remove PIN"
3. Enter current PIN
4. Toggle "Enable Parental Controls" to OFF

**Expected Result:**
- PIN verification required
- All content warnings removed
- Content unblurred across all tabs
- System disabled notification

## Edge Cases to Test

### 1. Multiple Languages in Same Content
Test content mixing multiple languages to ensure detection works.

### 2. Obfuscated Content
Test with special characters, numbers replacing letters (l33t speak).

### 3. Dynamic Content Loading
Test on websites with AJAX content loading (social media, comments).

### 4. High Volume Content
Test on pages with large amounts of text content.

### 5. Extension Reload
Test behavior when extension is reloaded or updated.

## Performance Testing

### 1. Content Scanning Speed
- Test on large pages
- Monitor CPU usage
- Check memory consumption

### 2. Real-time Monitoring
- Test mutation observer performance
- Check for any lag or freezing

## Browser Compatibility
Test on:
- Chrome (primary)
- Chromium-based browsers
- Different operating systems

## Security Testing

### 1. PIN Security
- Verify PIN is stored securely
- Test PIN encryption/hashing
- Ensure PIN isn't exposed in console

### 2. Content Script Security
- Check for XSS vulnerabilities
- Verify CSP compliance
- Test injection resistance

## Troubleshooting Common Issues

### Content Not Being Detected
1. Check if parental controls are enabled
2. Verify language filters are active
3. Confirm filter strength setting
4. Check browser console for errors

### PIN Not Working
1. Verify PIN was set correctly
2. Check for case sensitivity
3. Try resetting PIN through dashboard

### Settings Not Syncing
1. Check extension permissions
2. Verify storage access
3. Look for background script errors

### Performance Issues
1. Check content scanning efficiency
2. Monitor mutation observer performance
3. Verify memory usage patterns

## Success Criteria
- ✅ All inappropriate content detected across 6 languages
- ✅ PIN protection working correctly
- ✅ Real-time content filtering active
- ✅ Statistics and logging functional
- ✅ Achievement system rewarding protection
- ✅ Settings synchronization across tabs
- ✅ No performance degradation
- ✅ Secure PIN storage and verification

## Reporting Issues
When reporting issues, include:
1. Browser version and OS
2. Extension version
3. Steps to reproduce
4. Console error messages
5. Screenshots/videos if applicable

## Notes
- Test with real-world content scenarios
- Verify across different content types and platforms
- Ensure family-friendly browsing experience
- Check for false positives and adjust filters accordingly
