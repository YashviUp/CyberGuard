// Cyber Guard Pro - Advanced Content Script
// Comprehensive security monitoring and user protection

class CyberGuardContent {
  constructor() {
    this.isInitialized = false;
    this.securityConfig = {
      phishingPatterns: [
        /urgent.*action.*required/i,
        /verify.*account.*immediately/i,
        /click.*here.*to.*claim/i,
        /limited.*time.*offer/i,
        /suspicious.*activity.*detected/i
      ],
      maliciousDomains: [
        'suspicious-site.com',
        'fake-bank.net',
        'phishing-example.org'
      ]
    };
    this.threatLevel = 'low';
    this.init();
  }

  init() {
    if (this.isInitialized) return;
    this.isInitialized = true;
    
    this.setupEventListeners();
    this.performInitialScan();
    this.showWelcomeMessage();
  }

  setupEventListeners() {
    // Enhanced input monitoring
    document.addEventListener('input', this.handleInputEvent.bind(this), true);
    document.addEventListener('focusin', this.handleFocusEvent.bind(this), true);
    document.addEventListener('focusout', this.handleFocusOutEvent.bind(this), true);
    document.addEventListener('paste', this.handlePasteEvent.bind(this), true);
    
    // Form submission monitoring
    document.addEventListener('submit', this.handleFormSubmit.bind(this), true);
    
    // Click monitoring for suspicious links
    document.addEventListener('click', this.handleClickEvent.bind(this), true);
    
    // Page visibility changes
    document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
  }

  performInitialScan() {
    this.scanForPhishingIndicators();
    this.checkDomainReputation();
    this.analyzePageSecurity();
  }

  scanForPhishingIndicators() {
    const pageText = document.body.textContent.toLowerCase();
    const suspicious = this.securityConfig.phishingPatterns.some(pattern => 
      pattern.test(pageText)
    );
    
    if (suspicious) {
      this.threatLevel = 'high';
      this.showSecurityAlert('Potential phishing attempt detected on this page!', 'warning');
    }
  }

  checkDomainReputation() {
    const domain = window.location.hostname;
    const isMalicious = this.securityConfig.maliciousDomains.includes(domain);
    
    if (isMalicious) {
      this.threatLevel = 'critical';
      this.showBigPopup('🚨 DANGER: This website has been flagged as malicious! Leave immediately for your safety.');
    }
  }

  analyzePageSecurity() {
    const securityFeatures = {
      https: window.location.protocol === 'https:',
      mixedContent: this.detectMixedContent(),
      suspiciousScripts: this.detectSuspiciousScripts()
    };

    if (!securityFeatures.https && this.isLoginPage()) {
      this.showSecurityAlert('Warning: This login page is not secure (no HTTPS)', 'warning');
    }
  }

  detectMixedContent() {
    const images = document.querySelectorAll('img[src^="http:"]');
    const scripts = document.querySelectorAll('script[src^="http:"]');
    return images.length > 0 || scripts.length > 0;
  }

  detectSuspiciousScripts() {
    const scripts = document.querySelectorAll('script');
    return Array.from(scripts).some(script => {
      const src = script.src || script.textContent;
      return /eval\(|document\.write\(|fromCharCode/i.test(src);
    });
  }

  isLoginPage() {
    const passwordFields = document.querySelectorAll('input[type="password"]');
    const loginKeywords = /login|signin|sign.?in|log.?in/i;
    const pageText = document.title + document.body.textContent;
    return passwordFields.length > 0 || loginKeywords.test(pageText);
  }

  handleInputEvent(event) {
    const target = event.target;
    if (!this.isInputElement(target)) return;

    const value = target.value || target.textContent || '';
    
    // Check for abusive language
    if (this.containsBadWords(value)) {
      this.showBigPopup('Abusive or harmful language detected. Please maintain respectful communication! 🤝');
      target.focus();
      return;
    }

    // Check for sensitive data in inappropriate fields
    if (this.containsSensitiveData(value) && !this.isSensitiveField(target)) {
      this.showSecurityAlert('Caution: Sensitive information detected in unexpected field', 'info');
    }

    // Real-time password strength feedback
    if (target.type === 'password') {
      this.showPasswordStrengthFeedback(target, value);
    }
  }

  handleFocusEvent(event) {
    const target = event.target;
    
    if (target.type === 'password') {
      this.showPasswordSuggestion(target, '🔐 Tip: Use a strong, unique password with 12+ characters');
    }

    if (this.isSensitiveField(target)) {
      this.showSecurityAlert('Sensitive field detected - be cautious about sharing personal information', 'info');
    }
  }

  handleFocusOutEvent(event) {
    this.removePasswordSuggestion();
    this.removePasswordStrengthIndicator();
  }

  handlePasteEvent(event) {
    const clipboardData = event.clipboardData?.getData('text') || '';
    
    if (this.containsSensitiveData(clipboardData)) {
      const confirmed = confirm(
        'You are pasting what appears to be sensitive information. Are you sure this website is trustworthy?'
      );
      
      if (!confirmed) {
        event.preventDefault();
        this.showSecurityAlert('Paste operation cancelled for your security', 'info');
      }
    }
  }

  handleFormSubmit(event) {
    const form = event.target;
    const formData = new FormData(form);
    let hasSensitiveData = false;

    for (const [key, value] of formData.entries()) {
      if (this.containsSensitiveData(value.toString())) {
        hasSensitiveData = true;
        break;
      }
    }

    if (hasSensitiveData && !window.location.protocol.includes('https')) {
      event.preventDefault();
      this.showBigPopup('🛡️ Form submission blocked! This page is not secure (no HTTPS). Your sensitive data could be intercepted.');
    }
  }

  handleClickEvent(event) {
    const target = event.target.closest('a');
    if (!target) return;

    const href = target.href;
    if (this.isSuspiciousLink(href)) {
      event.preventDefault();
      const confirmed = confirm(
        `This link appears suspicious: ${href}\n\nAre you sure you want to continue?`
      );
      
      if (confirmed) {
        window.open(href, '_blank');
      } else {
        this.showSecurityAlert('Suspicious link click prevented', 'success');
      }
    }
  }

  handleVisibilityChange() {
    if (document.hidden) {
      chrome.runtime.sendMessage({ type: 'stopCounting' });
    } else {
      chrome.runtime.sendMessage({ type: 'startCounting' });
    }
  }

  // Security analysis methods
  isSuspiciousLink(href) {
    if (!href) return false;
    
    const suspiciousPatterns = [
      /bit\.ly|tinyurl|short\.link/i,
      /\.tk$|\.ml$|\.ga$/i,
      /download.*now|click.*here.*win/i
    ];
    
    return suspiciousPatterns.some(pattern => pattern.test(href));
  }

  containsSensitiveData(text) {
    if (!text) return false;
    
    const patterns = [
      /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/, // Credit card
      /\b\d{3}-\d{2}-\d{4}\b/, // SSN
      /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/, // Aadhaar
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/, // Email
      /\b\d{10,}\b/ // Phone numbers
    ];
    
    return patterns.some(pattern => pattern.test(text));
  }

  isSensitiveField(element) {
    const sensitiveTypes = ['password', 'email', 'tel'];
    const sensitiveNames = ['password', 'credit', 'card', 'cvv', 'ssn', 'aadhaar', 'pin'];
    const sensitivePatterns = /password|credit|card|cvv|ssn|aadhaar|pin|security|secret/i;
    
    return sensitiveTypes.includes(element.type) ||
           sensitiveNames.some(name => (element.name || '').toLowerCase().includes(name)) ||
           sensitivePatterns.test(element.placeholder || '') ||
           sensitivePatterns.test(element.id || '');
  }

  isInputElement(element) {
    return element.tagName === 'INPUT' || 
           element.tagName === 'TEXTAREA' || 
           element.isContentEditable;
  }

  // Password strength analysis
  showPasswordStrengthFeedback(inputElement, password) {
    const strength = this.calculatePasswordStrength(password);
    let existing = document.querySelector('.cyberguard-password-strength');
    
    if (existing) existing.remove();
    
    const indicator = document.createElement('div');
    indicator.className = 'cyberguard-password-strength';
    indicator.innerHTML = `
      <div style="font-size: 12px; margin-top: 4px; padding: 4px 8px; border-radius: 4px; background: ${strength.color}; color: white;">
        Password Strength: ${strength.text} (${strength.score}/5)
      </div>
    `;
    
    const rect = inputElement.getBoundingClientRect();
    indicator.style.position = 'absolute';
    indicator.style.top = (window.scrollY + rect.bottom + 4) + 'px';
    indicator.style.left = (window.scrollX + rect.left) + 'px';
    indicator.style.zIndex = '2147483647';
    
    document.body.appendChild(indicator);
  }

  calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[^a-zA-Z0-9]/.test(password)) score++;
    
    const levels = [
      { score: 0, text: 'Very Weak', color: '#dc3545' },
      { score: 1, text: 'Weak', color: '#fd7e14' },
      { score: 2, text: 'Fair', color: '#ffc107' },
      { score: 3, text: 'Good', color: '#20c997' },
      { score: 4, text: 'Strong', color: '#28a745' },
      { score: 5, text: 'Very Strong', color: '#007bff' }
    ];
    
    return { ...levels[Math.min(score, 5)], score };
  }

  removePasswordStrengthIndicator() {
    const existing = document.querySelector('.cyberguard-password-strength');
    if (existing) existing.remove();
  }

  // Enhanced security alerts and popups
  showSecurityAlert(message, type = 'info') {
    const colors = {
      info: '#17a2b8',
      warning: '#ffc107',
      success: '#28a745',
      danger: '#dc3545'
    };
    
    this.showSiteSuggestionPopup(message, colors[type]);
  }

  showWelcomeMessage() {
    setTimeout(() => {
      this.showSiteSuggestionPopup('🛡️ Cyber Guard Pro is protecting you! Stay vigilant and browse safely.', '#4a90e2');
    }, 1000);
  }

  // Utility methods for existing functionality
  containsBadWords(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    return BAD_WORDS.some(word => lower.includes(word));
  }

  containsSensitive(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    return SENSITIVE_FIELDS.some(field => lower.includes(field));
  }

  showSiteSuggestionPopup(message, color = 'rgba(74,144,226,0.95)') {
    let popup = document.createElement('div');
    popup.className = 'cyberguard-suggestion-popup';
    popup.textContent = message;
    popup.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: ${color};
      color: white;
      padding: 12px 22px;
      border-radius: 14px;
      font-family: Inter, Arial, sans-serif;
      font-size: 15px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.13);
      z-index: 2147483647;
      opacity: 0;
      transition: opacity 0.3s;
      max-width: 300px;
      word-wrap: break-word;
    `;
    
    document.body.appendChild(popup);
    setTimeout(() => { popup.style.opacity = '1'; }, 10);
    setTimeout(() => {
      popup.style.opacity = '0';
      setTimeout(() => { popup.remove(); }, 300);
    }, 5000);
  }

  showPasswordSuggestion(inputElement, message) {
    this.removePasswordSuggestion();
    
    let popup = document.createElement('div');
    popup.className = 'cyberguard-password-suggestion';
    popup.textContent = message;
    popup.style.cssText = `
      position: absolute;
      background: rgba(74,144,226,0.95);
      color: white;
      padding: 7px 16px;
      border-radius: 10px;
      font-family: Inter, Arial, sans-serif;
      font-size: 13px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.13);
      z-index: 2147483647;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.3s;
      max-width: 250px;
      word-wrap: break-word;
      white-space: normal;
    `;
    
    const rect = inputElement.getBoundingClientRect();
    popup.style.top = (window.scrollY + rect.top + rect.height / 2 - 18) + 'px';
    popup.style.left = (window.scrollX + rect.right + 12) + 'px';
    
    document.body.appendChild(popup);
    setTimeout(() => { popup.style.opacity = '1'; }, 10);
  }

  removePasswordSuggestion() {
    let existing = document.querySelector('.cyberguard-password-suggestion');
    if (existing) existing.remove();
  }

  showBigPopup(message) {
    const oldPopup = document.getElementById('cyberguard-big-popup');
    if (oldPopup) oldPopup.remove();

    const overlay = document.createElement('div');
    overlay.id = 'cyberguard-big-popup';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 2147483647;
      animation: cyberguard-fadein 0.5s;
    `;

    document.body.style.pointerEvents = 'none';
    overlay.style.pointerEvents = 'auto';

    const card = document.createElement('div');
    card.style.cssText = `
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(16px);
      border-radius: 28px;
      box-shadow: 0 12px 40px rgba(74,144,226,0.18), 0 2px 12px rgba(0,0,0,0.08);
      padding: 48px 40px 36px 40px;
      min-width: 350px;
      max-width: 90vw;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
    `;

    card.innerHTML = `
      <div style="margin-bottom: 12px;">
        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" style="display:block;margin:auto;">
          <defs>
            <linearGradient id="shieldGradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#4a90e2"/>
              <stop offset="100%" stop-color="#50e3c2"/>
            </linearGradient>
          </defs>
          <g>
            <path d="M30 6 L54 14 V28 C54 44 30 54 30 54 C30 54 6 44 6 28 V14 L30 6 Z" fill="url(#shieldGradient)" stroke="#357ABD" stroke-width="2"/>
            <path d="M30 20 L40 30 L26 44 L20 36" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
          </g>
        </svg>
      </div>
      <div style="font-size: 1.45rem; font-weight: 800; color: #357ABD; margin-bottom: 14px; letter-spacing: 0.5px;">
        Cyber Guard Pro Alert
      </div>
      <div style="font-size: 1.1rem; color: #222; margin-bottom: 8px; font-weight: 500;">
        ${message}
      </div>
      <button id="cyberguard-close-btn" style="margin-top: 28px; padding: 14px 36px; border: none; border-radius: 14px; background: linear-gradient(90deg, #4a90e2 0%, #50e3c2 100%); color: #fff; font-size: 1.1rem; font-weight: 700; box-shadow: 0 2px 8px rgba(74,144,226,0.10); cursor: pointer; outline: none; position: relative; overflow: hidden; transition: background 0.2s, transform 0.1s;">OK, I Understand</button>
    `;

    card.querySelector('#cyberguard-close-btn').onclick = () => {
      overlay.remove();
      document.body.style.pointerEvents = '';
    };

    // Add CSS animation if not exists
    if (!document.getElementById('cyberguard-popup-style')) {
      const style = document.createElement('style');
      style.id = 'cyberguard-popup-style';
      style.innerHTML = `@keyframes cyberguard-fadein { from { opacity: 0; } to { opacity: 1; } }`;
      document.head.appendChild(style);
    }

    overlay.appendChild(card);
    document.body.appendChild(overlay);
  }
}

// Existing constants (kept for compatibility)
const BAD_WORDS = new Set([
  // English Profanity
  "fuck", "fucker", "motherfucker", "shit", "bullshit", "crap", "bastard", "bitch", "son of a bitch",
  "slut", "whore", "hooker", "dick", "cock", "pussy", "cunt", "asshole", "arsehole", "twat", "prick",
  "wanker", "jerk", "douche", "douchebag", "cum", "jizz", "nutjob", "nutcase", "fag", "faggot", "retard",
  "nigger", "negro", "coon", "chink", "gook", "spic", "wetback", "beaner", "tranny", "he-she", "shemale",
  "queer", "dyke", "lesbo", "paki", "kike", "kafir", "infidel", "mofo", "ballsack", "dildo", "buttfuck",
  "shithead", "asshat", "shitface", "fuckface", "tit", "boobs", "tits", "nipple", "arse", "bugger", "bollocks", "bellend",

  // Hindi / Urdu / Punjabi
  "chutiya", "bhenchod", "madarchod", "loda", "lund", "lavda", "gaand", "gandu", "chut", "randi", "haraami",
  "haraamzada", "kutte", "kutti", "saala", "saali", "launda", "chod", "chodne", "chodna", "chodu", "chudai",
  "puki", "bhosdi", "bhosadike", "bakchod", "pimp", "nangi", "kamina", "kameeni", "bhadwa", "bhadwe", "chinal",
  "chinaal", "gaand mara", "chus le", "chusna", "jhatu", "jhant", "jhantichod", "jhav", "jhavaNe", "lund choos",

  // Tamil / Telugu / Kannada
  "soothu", "pundai", "otha", "ommaala", "koodhi", "shithi", "panni", "sori naai", "mandha buddhi", "paithiyam",
  "koomuttai", "muttaal", "loosu", "karumam", "porambokku", "erumai", "maanangettava", "nayala", "kunda", "kundi",
  "naaye", "kirukkan", "kasmalam", "paradesi", "kedi", "seththuppo", "thendi", "aambala", "thiruttu", "sootha kutti",

  // Marathi / Gujarati / Bengali / Odia
  "rand", "veshya", "chinAl", "bhadva", "bhadavyA", "aijhavADyA", "phodarIchyA", "toMDAt ghe", "chokh mAjhA lavaDA",
  "bahutAta", "yabhati", "pAyu", "bhagAsya", "jAragarbha", "veshyAsuta", "kanjar", "khotya", "kamino", "chodibaaj",
  "gandfattu", "chodanari", "ulanga", "chodfodu",

  // Filter Evasion / Leet Variants
  "f*ck", "f@ck", "fcuk", "phuck", "fuk", "sh1t", "s#it", "b!tch", "b1tch", "bi7ch", "a$$hole", "a55hole",
  "pu$$y", "d1ck", "c0ck", "c*nt", "tw@t", "w@nker", "w4nker", "n1gger", "n!gger", "b@stard", "s!ut", "s1ut",
  "wh0re", "wh@re", "s0n of a b!tch", "l@vda", "m@darchod", "b#enchod", "c#tiya", "r@ndi"
]);

const SENSITIVE_FIELDS = [
  'password', 'credit', 'card', 'cvv', 'ssn', 'aadhaar', 'upi', 'atm', 'pin', 'debit', 'account', 'mobile', 'phone', 'address'
];

// Initialize enhanced content protection
const cyberGuardContent = new CyberGuardContent();

// Handle messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'showBigPopup') {
    cyberGuardContent.showBigPopup(message.reason);
    sendResponse({ status: 'popup shown' });
  }
  return true;
});
