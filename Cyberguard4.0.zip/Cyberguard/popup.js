// Cyber Guard Pro - Enhanced Popup Controller
// Modern interface with comprehensive security features

class CyberGuardPopup {
  constructor() {
    this.lastUsage = 0;
    this.lastFetched = Date.now();
    this.updateInterval = null;
    this.liveTimerInterval = null;
    this.maxDailyTime = 3 * 60 * 60 * 1000; // 3 hours
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.startDataUpdates();
    this.loadInitialData();
  }

  setupEventListeners() {
    // Dashboard button
    document.getElementById('openDashboard').addEventListener('click', () => {
      this.openDashboard();
    });

    // Quick scan button
    document.getElementById('runScan').addEventListener('click', () => {
      this.performQuickScan();
    });

    // Protection toggle button
    document.getElementById('toggleProtection').addEventListener('click', () => {
      this.toggleProtection();
    });
  }

  startDataUpdates() {
    // Update data every 30 seconds
    this.updateInterval = setInterval(() => {
      this.updateAllData();
    }, 30000);

    // Update live timer every second
    this.liveTimerInterval = setInterval(() => {
      this.updateLiveTimer();
    }, 1000);
  }

  loadInitialData() {
    this.updateAllData();
  }

  async updateAllData() {
    try {
      const data = await this.getDashboardData();
      this.lastUsage = data.dailyUsage || 0;
      this.lastFetched = Date.now();
      
      this.updateTimeDisplay(this.lastUsage);
      this.updateProgressBar(this.lastUsage);
      this.updateStats(data);
      this.updateLastScan(data);
    } catch (error) {
      console.error('Failed to update popup data:', error);
    }
  }

  updateLiveTimer() {
    const now = Date.now();
    const elapsed = now - this.lastFetched;
    const currentUsage = this.lastUsage + elapsed;
    this.updateTimeDisplay(currentUsage);
    this.updateProgressBar(currentUsage);
  }

  updateTimeDisplay(usage) {
    const timeString = this.msToHms(usage);
    document.getElementById('totalTime').textContent = timeString;
  }

  updateProgressBar(usage) {
    const progressElement = document.getElementById('timeProgress');
    if (progressElement) {
      const percentage = Math.min((usage / this.maxDailyTime) * 100, 100);
      progressElement.style.width = `${percentage}%`;
      
      // Update color based on usage
      if (percentage > 90) {
        progressElement.style.background = 'linear-gradient(90deg, #f56565 0%, #fc8181 100%)';
      } else if (percentage > 70) {
        progressElement.style.background = 'linear-gradient(90deg, #ed8936 0%, #f6ad55 100%)';
      } else {
        progressElement.style.background = 'linear-gradient(90deg, #4a90e2 0%, #50e3c2 100%)';
      }
    }
  }

  updateStats(data) {
    const securityStats = data.securityStats || {};
    
    // Update threats blocked
    const threatsElement = document.getElementById('threatsBlocked');
    if (threatsElement) {
      threatsElement.textContent = securityStats.threatsBlocked || 0;
    }

    // Update privacy score
    const privacyElement = document.getElementById('privacyScore');
    if (privacyElement) {
      privacyElement.textContent = data.privacyScore || 85;
    }

    // Update scan count
    const scanElement = document.getElementById('scanCount');
    if (scanElement) {
      scanElement.textContent = securityStats.scansPerformed || 0;
    }
  }

  updateLastScan(data) {
    const lastScanElement = document.getElementById('lastScan');
    if (lastScanElement && data.securityStats?.lastScanDate) {
      const lastScanDate = new Date(data.securityStats.lastScanDate);
      const now = new Date();
      const diffMinutes = Math.floor((now - lastScanDate) / (1000 * 60));
      
      let timeText;
      if (diffMinutes < 1) {
        timeText = 'Just now';
      } else if (diffMinutes < 60) {
        timeText = `${diffMinutes}m ago`;
      } else if (diffMinutes < 1440) {
        const hours = Math.floor(diffMinutes / 60);
        timeText = `${hours}h ago`;
      } else {
        const days = Math.floor(diffMinutes / 1440);
        timeText = `${days}d ago`;
      }
      
      lastScanElement.textContent = timeText;
    }
  }

  msToHms(duration) {
    const seconds = Math.floor((duration / 1000) % 60);
    const minutes = Math.floor((duration / (1000 * 60)) % 60);
    const hours = Math.floor((duration / (1000 * 60 * 60)));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  }

  openDashboard() {
    chrome.tabs.create({ 
      url: chrome.runtime.getURL('dashboard.html') 
    });
    window.close();
  }

  async performQuickScan() {
    const scanButton = document.getElementById('runScan');
    const originalText = scanButton.innerHTML;
    
    // Show loading state
    scanButton.classList.add('loading');
    scanButton.innerHTML = '<span class="btn-icon">🔍</span><span class="btn-text">Scanning...</span>';
    scanButton.disabled = true;

    try {
      // Request security scan from background
      const result = await this.sendMessage({ type: 'performSecurityScan' });
      
      // Show brief success notification
      this.showNotification('Quick scan completed successfully!', 'success');
      
      // Update stats after scan
      setTimeout(() => {
        this.updateAllData();
      }, 1000);
      
    } catch (error) {
      console.error('Quick scan failed:', error);
      this.showNotification('Scan failed. Please try again.', 'error');
    } finally {
      // Restore button state
      scanButton.classList.remove('loading');
      scanButton.innerHTML = originalText;
      scanButton.disabled = false;
    }
  }

  async toggleProtection() {
    const protectionButton = document.getElementById('toggleProtection');
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.querySelector('.status-text');
    
    // Get current protection state (simulate for now)
    const isProtected = statusDot.classList.contains('active');
    
    try {
      if (isProtected) {
        // Disable protection
        statusDot.classList.remove('active');
        statusDot.style.background = '#f56565';
        statusText.textContent = 'Disabled';
        statusText.style.color = '#f56565';
        protectionButton.innerHTML = '<span class="btn-icon">🛡️</span><span class="btn-text">Enable</span>';
        this.showNotification('Protection disabled', 'warning');
      } else {
        // Enable protection
        statusDot.classList.add('active');
        statusDot.style.background = '#48bb78';
        statusText.textContent = 'Protected';
        statusText.style.color = '#48bb78';
        protectionButton.innerHTML = '<span class="btn-icon">🛡️</span><span class="btn-text">Protection</span>';
        this.showNotification('Protection enabled', 'success');
      }
    } catch (error) {
      console.error('Failed to toggle protection:', error);
      this.showNotification('Failed to toggle protection', 'error');
    }
  }

  showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `popup-notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      color: white;
      z-index: 10000;
      opacity: 0;
      transform: translateY(-20px);
      transition: all 0.3s ease;
      max-width: 300px;
      word-wrap: break-word;
    `;

    // Set background color based on type
    const colors = {
      success: '#48bb78',
      error: '#f56565',
      warning: '#ed8936',
      info: '#4a90e2'
    };
    notification.style.background = colors[type] || colors.info;

    // Add to document
    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateY(0)';
    }, 100);

    // Remove after 3 seconds
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transform = 'translateY(-20px)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }

  getDashboardData() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'getDashboardData' }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
  }

  sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
  }

  destroy() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
    if (this.liveTimerInterval) {
      clearInterval(this.liveTimerInterval);
    }
  }
}

// Initialize popup when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.cyberGuardPopup = new CyberGuardPopup();
});

// Cleanup when popup is closed
window.addEventListener('beforeunload', () => {
  if (window.cyberGuardPopup) {
    window.cyberGuardPopup.destroy();
  }
});
