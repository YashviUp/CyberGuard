// Cyber Guard Pro - Enhanced Dashboard JavaScript
// Comprehensive analytics, gamification, and management interface

// Dashboard Controller Class
class CyberGuardDashboard {
    constructor() {
        this.data = {};
        this.charts = {};
        this.themeManager = new ThemeManager();
        
        this.init();
    }
    
    async init() {
        this.bindEvents();
        await this.loadData();
        this.setupCharts();
        this.updateUI();
        this.startAutoRefresh();
        
        // Show loading complete
        this.hideLoadingStates();
    }
      bindEvents() {
        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.themeManager.toggleTheme();
            });
        }
        
        // Settings controls
        const timeLimitSlider = document.getElementById('timeLimitSlider');
        if (timeLimitSlider) {
            timeLimitSlider.addEventListener('input', (e) => {
                const hours = parseFloat(e.target.value);
                document.getElementById('timeLimitValue').textContent = hours + ' hours';
            });
        }
        
        const saveSettings = document.getElementById('saveSettings');
        if (saveSettings) {
            saveSettings.addEventListener('click', () => {
                this.saveSettings();
            });
        }
        
        // Action buttons
        const fullSecurityScan = document.getElementById('fullSecurityScan');
        if (fullSecurityScan) {
            fullSecurityScan.addEventListener('click', () => {
                this.performFullSecurityScan();
            });
        }
        
        const exportData = document.getElementById('exportData');
        if (exportData) {
            exportData.addEventListener('click', () => {
                this.exportData();
            });
        }
        
        const helpSupport = document.getElementById('helpSupport');
        if (helpSupport) {
            helpSupport.addEventListener('click', () => {
                this.openHelp();
            });
        }
        
        // Time filter
        const timeFilter = document.getElementById('timeFilter');
        if (timeFilter) {
            timeFilter.addEventListener('change', (e) => {
                this.updateAnalytics(e.target.value);
            });
        }
    }
    
    async loadData() {
        try {
            this.data = await new Promise((resolve) => {
                chrome.runtime.sendMessage({ type: 'getDashboardData' }, resolve);
            });
            
            if (!this.data) {
                this.data = this.getDefaultData();
            }
        } catch (error) {
            console.error('Failed to load data:', error);
            this.data = this.getDefaultData();
        }
    }
    
    getDefaultData() {
        return {
            dailyUsage: 0,
            browsingHistory: {},
            achievements: { unlocked: [], xp: 0, level: 1, streak: 0 },
            securityStats: {
                threatsBlocked: 0,
                sensitiveDataProtected: 0,
                phishingAttemptsBlocked: 0,
                maliciousSitesBlocked: 0
            },
            userPreferences: {
                dailyLimit: 3 * 60 * 60 * 1000,
                notifications: true,
                contentFiltering: 'standard',
                securityLevel: 'balanced',
                theme: 'auto'
            }
        };
    }
    
    updateUI() {
        this.updateStats();
        this.updateUserProfile();
        this.updateSecurityStatus();
        this.updateSitesList();
        this.updateAchievements();
        this.updatePrivacyInsights();
        this.updateSettings();
    }
    
    updateStats() {
        const stats = this.calculateStats();
        
        // Update stat cards with animations
        this.animateValue('totalTimeToday', stats.timeToday);
        this.animateValue('threatsBlocked', stats.threatsBlocked);
        this.animateValue('achievementCount', stats.achievements);
        this.animateValue('privacyScore', stats.privacyScore + '%');
          // Update additional stats
        const dailyAverageElement = document.getElementById('dailyAverage');
        if (dailyAverageElement) dailyAverageElement.textContent = stats.dailyAverage;
        
        const peakHoursElement = document.getElementById('peakHours');
        if (peakHoursElement) peakHoursElement.textContent = stats.peakHours;
        
        const currentStreakElement = document.getElementById('currentStreak');
        if (currentStreakElement) currentStreakElement.textContent = stats.streak + ' days';
        
        const totalSitesElement = document.getElementById('totalSites');
        if (totalSitesElement) totalSitesElement.textContent = stats.uniqueSites;
    }
    
    calculateStats() {
        const history = this.data.browsingHistory || {};
        const achievements = this.data.achievements || {};
        const security = this.data.securityStats || {};
        
        return {
            timeToday: this.msToHms(this.data.dailyUsage || 0),
            threatsBlocked: security.threatsBlocked || 0,
            achievements: (achievements.unlocked || []).length,
            privacyScore: this.calculatePrivacyScore(),
            dailyAverage: this.msToHms(this.data.dailyUsage || 0),
            peakHours: this.calculatePeakHours(),
            streak: achievements.streak || 0,
            uniqueSites: Object.keys(history).length
        };
    }
    
    calculatePrivacyScore() {
        // Simplified privacy score calculation
        let score = 100;
        const factors = [];
        
        // Check browsing patterns
        const history = this.data.browsingHistory || {};
        const sites = Object.keys(history);
        
        sites.forEach(site => {
            if (site.includes('facebook') || site.includes('google') || site.includes('amazon')) {
                score -= 5;
            }
        });
        
        return Math.max(score, 60);
    }
    
    calculatePeakHours() {
        // Mock peak hours calculation
        const hour = new Date().getHours();
        
        if (hour >= 9 && hour <= 12) return '9-12 AM';
        if (hour >= 14 && hour <= 17) return '2-5 PM';
        if (hour >= 19 && hour <= 22) return '7-10 PM';
        return 'Variable';
    }
      updateUserProfile() {
        const achievements = this.data.achievements || {};
        const level = Math.floor((achievements.xp || 0) / 1000) + 1;
        const userLevelElement = document.getElementById('userLevel');
        if (userLevelElement) userLevelElement.textContent = level;
    }
    
    updateSecurityStatus() {
        const security = this.data.securityStats || {};
        document.getElementById('blockedToday').textContent = security.threatsBlocked || 0;
        document.getElementById('dataProtected').textContent = security.sensitiveDataProtected || 0;
        document.getElementById('totalThreats').textContent = security.threatsBlocked || 0;
    }
    
    updateSitesList() {
        const sitesList = document.getElementById('sitesList');
        const history = this.data.browsingHistory || {};
        
        if (Object.keys(history).length === 0) {
            sitesList.innerHTML = '<div style="color:#aaa; text-align: center; padding: 20px;">No browsing data available for today.</div>';
            return;
        }
        
        // Sort sites by time spent
        const sortedSites = Object.entries(history)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10); // Show top 10 sites
        
        sitesList.innerHTML = sortedSites.map(([domain, timeMs]) => {
            const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=24`;
            return `
                <div class="site-item">
                    <div class="site-info">
                        <img class="site-favicon" src="${favicon}" alt="${domain}" onerror="this.style.display='none'">
                        <span class="site-name">${domain}</span>
                    </div>
                    <div class="site-time">${this.msToHms(timeMs)}</div>
                </div>
            `;
        }).join('');
    }
      updateAchievements() {
        const achievementsGrid = document.getElementById('achievementsGrid');
        const unlocked = this.data.achievements && this.data.achievements.unlocked || [];
        
        const allAchievements = [
            { name: 'First Steps', icon: '👶', description: 'Started using Cyber Guard' },
            { name: 'Time Keeper', icon: '⏰', description: 'Tracked time for 7 days' },
            { name: 'Security Pro', icon: '🛡️', description: 'Blocked 100 threats' },
            { name: 'Privacy Master', icon: '🔐', description: 'Maintained 90% privacy score' },
            { name: 'Streak Warrior', icon: '🔥', description: '30-day usage streak' },
            { name: 'Clean Browser', icon: '✨', description: 'No toxic content for 14 days' }
        ];
        
        achievementsGrid.innerHTML = allAchievements.map(achievement => {
            const isUnlocked = unlocked.some(a => a.title === achievement.name);
            return `
                <div class="achievement-badge ${isUnlocked ? 'unlocked' : ''}">
                    <div class="achievement-icon">${achievement.icon}</div>
                    <div class="achievement-name">${achievement.name}</div>
                </div>
            `;
        }).join('');
    }
    
    updatePrivacyInsights() {
        const privacyScore = this.calculatePrivacyScore();
        document.getElementById('overallPrivacyScore').textContent = privacyScore;
        
        // Update privacy factors based on browsing history
        const history = this.data.browsingHistory || {};
        const sites = Object.keys(history);
        
        const privacyTips = [
            "Use strong, unique passwords for each account",
            "Enable two-factor authentication when available",
            "Regularly review app permissions",
            "Keep your browser and extensions updated",
            "Use private/incognito mode for sensitive browsing"
        ];
        
        document.getElementById('privacyTips').innerHTML = privacyTips
            .slice(0, 3)
            .map(tip => `<li>${tip}</li>`)
            .join('');
    }
    
    updateSettings() {
        const prefs = this.data.userPreferences || {};
        
        // Update time limit slider
        const timeLimitHours = (prefs.dailyLimit || 10800000) / (1000 * 60 * 60);
        document.getElementById('timeLimitSlider').value = timeLimitHours;
        document.getElementById('timeLimitValue').textContent = timeLimitHours + ' hours';
        
        // Update other settings
        document.getElementById('contentFilterLevel').value = prefs.contentFiltering || 'standard';
        document.getElementById('notificationsEnabled').checked = prefs.notifications !== false;
        document.getElementById('securityLevel').value = prefs.securityLevel || 'balanced';
    }
    
    setupCharts() {
        this.setupUsageChart();
    }
      setupUsageChart() {
        const ctx = document.getElementById('usageChart');
        if (!ctx) return;
        
        // Check if Chart.js is available
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js not loaded, displaying fallback chart');
            this.displayFallbackChart(ctx);
            return;
        }
        
        try {
            // Generate mock data for the chart
            const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            const data = [2.5, 3.2, 2.8, 4.1, 3.5, 1.8, 2.2]; // Hours
            
            this.charts.usage = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Hours',
                        data: data,
                        borderColor: '#4a90e2',
                        backgroundColor: 'rgba(74, 144, 226, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 5,
                            ticks: {
                                callback: function(value) {
                                    return value + 'h';
                                }
                            }
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Chart.js error:', error);
            this.displayFallbackChart(ctx);
        }
    }      displayFallbackChart(canvas) {
        const container = canvas.parentElement;
        
        // Get website usage data from browsing history
        const history = this.data.browsingHistory || {};
        const topSites = Object.entries(history)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([domain, visits]) => ({
                domain: domain.replace('www.', ''),
                visits: visits,
                percentage: Math.min((visits / Math.max(...Object.values(history))) * 100, 100)
            }));
        
        // Generate website bars HTML
        const websiteUsageHtml = topSites.length > 0 ? 
            topSites.map((site, index) => {
                const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57'];
                const height = Math.max(site.percentage * 0.8, 20); // Minimum 20px height
                return `
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px; flex: 1;">
                        <div style="
                            width: 24px; 
                            height: ${height}px; 
                            background: ${colors[index]}; 
                            border-radius: 4px 4px 0 0;
                            transition: all 0.3s ease;
                            position: relative;
                            overflow: hidden;
                        ">
                            <div style="
                                position: absolute;
                                top: 0;
                                left: 0;
                                width: 100%;
                                height: 100%;
                                background: linear-gradient(45deg, rgba(255,255,255,0.1) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0.1) 75%, transparent 75%);
                                background-size: 8px 8px;
                                animation: slide 2s infinite linear;
                            "></div>
                        </div>
                        <span style="font-size: 0.6rem; text-align: center; max-width: 40px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${site.domain}">${site.domain}</span>
                        <span style="font-size: 0.5rem; opacity: 0.7;">${site.visits}</span>
                    </div>
                `;
            }).join('') :
            `<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: rgba(255,255,255,0.7); font-size: 0.8rem;">
                No browsing data available for today
            </div>`;

        container.innerHTML = `
            <style>
                @keyframes slide {
                    0% { transform: translateX(-8px); }
                    100% { transform: translateX(8px); }
                }
                @keyframes pulse {
                    0%, 100% { opacity: 0.8; }
                    50% { opacity: 1; }
                }
                .chart-tabs {
                    display: flex;
                    gap: 8px;
                    margin-bottom: 16px;
                }
                .chart-tab {
                    padding: 6px 12px;
                    background: rgba(255,255,255,0.2);
                    border: none;
                    border-radius: 6px;
                    color: white;
                    font-size: 0.7rem;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }
                .chart-tab.active, .chart-tab:hover {
                    background: rgba(255,255,255,0.3);
                    transform: translateY(-1px);
                }
            </style>
            <div style="
                display: flex;
                flex-direction: column;
                height: 300px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 12px;
                color: white;
                padding: 20px;
                position: relative;
                overflow: hidden;
            ">
                <!-- Header -->
                <div style="
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 16px;
                ">
                    <div>
                        <div style="font-size: 1.1rem; font-weight: 600;">📊 Usage Analytics</div>
                        <div style="font-size: 0.8rem; opacity: 0.8;">Built-in Dashboard (Chart.js unavailable)</div>
                    </div>
                    <div style="font-size: 0.7rem; opacity: 0.7;">Today</div>
                </div>
                
                <!-- Chart Tabs -->
                <div class="chart-tabs">
                    <button class="chart-tab active" onclick="switchFallbackChart('time')">📈 Time Trends</button>
                    <button class="chart-tab" onclick="switchFallbackChart('sites')">🌐 Top Sites</button>
                </div>
                
                <!-- Time Trends Chart -->
                <div id="timeChart" style="
                    display: flex;
                    align-items: end;
                    justify-content: space-between;
                    height: 100px;
                    margin-bottom: 15px;
                    padding: 0 10px;
                ">
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 65px; background: rgba(255,255,255,0.7); border-radius: 3px 3px 0 0; animation: pulse 2s infinite;"></div>
                        <span style="font-size: 0.65rem;">Mon</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 85px; background: rgba(255,255,255,0.8); border-radius: 3px 3px 0 0; animation: pulse 2s infinite 0.2s;"></div>
                        <span style="font-size: 0.65rem;">Tue</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 75px; background: rgba(255,255,255,0.75); border-radius: 3px 3px 0 0; animation: pulse 2s infinite 0.4s;"></div>
                        <span style="font-size: 0.65rem;">Wed</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 95px; background: rgba(255,255,255,0.9); border-radius: 3px 3px 0 0; box-shadow: 0 2px 8px rgba(0,0,0,0.2); animation: pulse 2s infinite 0.6s;"></div>
                        <span style="font-size: 0.65rem;">Thu</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 88px; background: rgba(255,255,255,0.85); border-radius: 3px 3px 0 0; animation: pulse 2s infinite 0.8s;"></div>
                        <span style="font-size: 0.65rem;">Fri</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 45px; background: rgba(255,255,255,0.6); border-radius: 3px 3px 0 0; animation: pulse 2s infinite 1s;"></div>
                        <span style="font-size: 0.65rem;">Sat</span>
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                        <div style="width: 20px; height: 55px; background: rgba(255,255,255,0.65); border-radius: 3px 3px 0 0; animation: pulse 2s infinite 1.2s;"></div>
                        <span style="font-size: 0.65rem;">Sun</span>
                    </div>
                </div>
                
                <!-- Website Usage Chart -->
                <div id="sitesChart" style="
                    display: none;
                    height: 100px;
                    margin-bottom: 15px;
                    padding: 0 10px;
                ">
                    <div style="
                        display: flex;
                        align-items: end;
                        justify-content: space-around;
                        height: 80px;
                        gap: 8px;
                    ">
                        ${websiteUsageHtml}
                    </div>
                </div>
                
                <!-- Stats Row -->
                <div style="
                    display: flex;
                    justify-content: space-around;
                    margin-top: auto;
                    padding-top: 15px;
                    border-top: 1px solid rgba(255,255,255,0.3);
                ">
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 600;">${this.msToHms(this.data.dailyUsage || 0)}</div>
                        <div style="font-size: 0.7rem; opacity: 0.8;">Today</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 600;">${Object.keys(history).length}</div>
                        <div style="font-size: 0.7rem; opacity: 0.8;">Sites</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 1rem; font-weight: 600;">${this.calculatePeakHours()}</div>
                        <div style="font-size: 0.7rem; opacity: 0.8;">Peak</div>
                    </div>
                </div>
                
                <!-- Background decoration -->
                <div style="
                    position: absolute;
                    top: -30px;
                    right: -30px;
                    width: 120px;
                    height: 120px;
                    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
                    border-radius: 50%;
                    opacity: 0.4;
                "></div>
                <div style="
                    position: absolute;
                    bottom: -20px;
                    left: -20px;
                    width: 80px;
                    height: 80px;
                    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
                    border-radius: 50%;
                    opacity: 0.6;
                "></div>
            </div>
        `;
        
        // Add tab switching functionality to global scope
        window.switchFallbackChart = (type) => {
            const timeChart = document.getElementById('timeChart');
            const sitesChart = document.getElementById('sitesChart');
            const tabs = document.querySelectorAll('.chart-tab');
            
            tabs.forEach(tab => tab.classList.remove('active'));
            
            if (type === 'time') {
                timeChart.style.display = 'flex';
                sitesChart.style.display = 'none';
                tabs[0].classList.add('active');
            } else {
                timeChart.style.display = 'none';
                sitesChart.style.display = 'block';
                tabs[1].classList.add('active');
            }
        };
    }
    
    async saveSettings() {
        const button = document.getElementById('saveSettings');
        const originalText = button.querySelector('.btn-text').textContent;
        
        button.querySelector('.btn-text').textContent = 'Saving...';
        button.disabled = true;
        
        try {
            const preferences = {
                dailyLimit: parseFloat(document.getElementById('timeLimitSlider').value) * 60 * 60 * 1000,
                contentFiltering: document.getElementById('contentFilterLevel').value,
                notifications: document.getElementById('notificationsEnabled').checked,
                securityLevel: document.getElementById('securityLevel').value
            };
            
            await new Promise((resolve) => {
                chrome.runtime.sendMessage({
                    type: 'updatePreferences',
                    preferences: preferences
                }, resolve);
            });
            
            this.showNotification('Settings saved successfully!', 'success');
            
        } catch (error) {
            console.error('Failed to save settings:', error);
            this.showNotification('Failed to save settings', 'error');
        } finally {
            button.querySelector('.btn-text').textContent = originalText;
            button.disabled = false;
        }
    }
    
    async performFullSecurityScan() {
        const button = document.getElementById('fullSecurityScan');
        const originalText = button.querySelector('.btn-text').textContent;
        
        button.querySelector('.btn-text').textContent = 'Scanning...';
        button.querySelector('.btn-icon').textContent = '🔄';
        button.disabled = true;
        
        try {
            // Simulate comprehensive security scan
            await this.simulateSecurityScan();
            
            button.querySelector('.btn-text').textContent = 'Scan Complete!';
            button.querySelector('.btn-icon').textContent = '✅';
            
            this.showNotification('Security scan completed successfully!', 'success');
            
            // Award achievement
            chrome.runtime.sendMessage({
                type: 'unlockAchievement',
                achievementType: 'SECURITY_AWARE',
                title: 'Full Security Scan',
                xpReward: 100,
                message: 'Performed a comprehensive security scan!'
            });
            
        } catch (error) {
            console.error('Security scan failed:', error);
            button.querySelector('.btn-text').textContent = 'Scan Failed';
            button.querySelector('.btn-icon').textContent = '❌';
            this.showNotification('Security scan failed', 'error');
        } finally {
            setTimeout(() => {
                button.querySelector('.btn-text').textContent = originalText;
                button.querySelector('.btn-icon').textContent = '🔍';
                button.disabled = false;
            }, 3000);
        }
    }
    
    async simulateSecurityScan() {
        // Simulate various security checks
        const checks = [
            'Checking for malware...',
            'Scanning browser extensions...',
            'Verifying website certificates...',
            'Analyzing browsing patterns...',
            'Checking for data leaks...',
            'Validating security settings...'
        ];
        
        for (const check of checks) {
            await new Promise(resolve => setTimeout(resolve, 500));
            console.log(check);
        }
    }
    
    exportData() {
        try {
            const exportData = {
                version: '4.0',
                exportDate: new Date().toISOString(),
                dailyUsage: this.data.dailyUsage,
                browsingHistory: this.data.browsingHistory,
                achievements: this.data.achievements,
                securityStats: this.data.securityStats,
                userPreferences: this.data.userPreferences
            };
            
            const blob = new Blob([JSON.stringify(exportData, null, 2)], {
                type: 'application/json'
            });
            
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `cyberguard-data-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Data exported successfully!', 'success');
            
        } catch (error) {
            console.error('Export failed:', error);
            this.showNotification('Failed to export data', 'error');
        }
    }
    
    openHelp() {
        const helpContent = `
            <h3>Dashboard Features:</h3>
            <ul>
                <li><strong>Usage Analytics:</strong> Track your daily browsing time and patterns</li>
                <li><strong>Security Status:</strong> Monitor threats blocked and security metrics</li>
                <li><strong>Achievements:</strong> Earn XP and unlock badges for good digital habits</li>
                <li><strong>Privacy Insights:</strong> Understand your privacy score and get tips</li>
                <li><strong>Settings:</strong> Customize time limits, security levels and preferences</li>
            </ul>
            <p>Need more help? Visit our support page or contact us at support@cyberguardpro.com</p>
        `;
        
        this.showModal('Help & Support', helpContent);
    }
    
    updateAnalytics(timeframe) {
        // Update charts based on selected timeframe
        if (this.charts.usage) {
            let labels, data;
            
            switch (timeframe) {
                case 'today':
                    labels = Array.from({length: 24}, (_, i) => i + ':00');
                    data = Array.from({length: 24}, () => Math.random() * 0.5);
                    break;
                case 'week':
                    labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    data = [2.5, 3.2, 2.8, 4.1, 3.5, 1.8, 2.2];
                    break;
                case 'month':
                    labels = Array.from({length: 30}, (_, i) => (i + 1).toString());
                    data = Array.from({length: 30}, () => Math.random() * 5);
                    break;
            }
            
            this.charts.usage.data.labels = labels;
            this.charts.usage.data.datasets[0].data = data;
            this.charts.usage.update();
        }
    }
    
    // Utility functions
    msToHms(duration) {
        const seconds = Math.floor((duration / 1000) % 60);
        const minutes = Math.floor((duration / (1000 * 60)) % 60);
        const hours = Math.floor((duration / (1000 * 60 * 60)));
        
        return `${hours}h ${minutes}m ${seconds}s`;
    }
    
    animateValue(elementId, targetValue) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        element.textContent = targetValue;
        element.style.animation = 'slideIn 0.5s ease-out';
    }
    
    showNotification(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-icon">
                ${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}
            </div>
            <div class="notification-message">${message}</div>
            <button class="notification-close">×</button>
        `;
        
        notification.style.cssText = `
            background: ${type === 'success' ? '#48bb78' : type === 'error' ? '#f56565' : '#4a90e2'};
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease-out;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        `;
        
        container.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
        
        // Manual close
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
    }
    
    showModal(title, content) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        `;
        
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        `;
        
        const modalContent = modal.querySelector('.modal-content');
        modalContent.style.cssText = `
            background: white;
            border-radius: 12px;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        `;
        
        const modalHeader = modal.querySelector('.modal-header');
        modalHeader.style.cssText = `
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        `;
        
        const modalBody = modal.querySelector('.modal-body');
        modalBody.style.cssText = `
            padding: 24px;
            line-height: 1.6;
        `;
        
        document.body.appendChild(modal);
        
        // Close modal handlers
        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    hideLoadingStates() {
        document.querySelectorAll('.sites-loading, .chart-loading').forEach(el => {
            el.style.display = 'none';
        });
    }
    
    startAutoRefresh() {
        // Refresh data every 30 seconds
        setInterval(async () => {
            await this.loadData();
            this.updateUI();
        }, 30000);
    }
}

// Theme Manager Class
class ThemeManager {
    constructor() {
        this.currentTheme = localStorage.getItem('cyberguard-theme') || 'auto';
        this.applyTheme();
    }
    
    applyTheme() {
        const body = document.body;
        
        if (this.currentTheme === 'dark') {
            body.classList.add('dark-theme');
        } else if (this.currentTheme === 'light') {
            body.classList.remove('dark-theme');
        } else {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            body.classList.toggle('dark-theme', prefersDark);
        }
        
        // Update theme toggle icon
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icons = { light: '☀️', dark: '🌙', auto: '🌓' };
            themeToggle.querySelector('.theme-icon').textContent = icons[this.currentTheme];
        }
    }
    
    toggleTheme() {
        const themes = ['light', 'dark', 'auto'];
        const currentIndex = themes.indexOf(this.currentTheme);
        this.currentTheme = themes[(currentIndex + 1) % themes.length];
        
        localStorage.setItem('cyberguard-theme', this.currentTheme);
        this.applyTheme();
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new CyberGuardDashboard();
    
    // Add entrance animation
    document.querySelector('.dashboard-container').style.animation = 'slideIn 0.8s ease-out';
    
    console.log('Cyber Guard Pro Dashboard loaded successfully');
});

// Handle window resize for responsive charts
window.addEventListener('resize', () => {
    const charts = window.dashboard && window.dashboard.charts || {};
    Object.values(charts).forEach(chart => {
        if (chart && chart.resize) {
            chart.resize();
        }
    });
});
