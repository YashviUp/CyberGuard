# Cyber Guard Pro - Testing Guide

## Installation & Testing Instructions

### 1. Load Extension in Chrome

1. **Open Chrome Extensions Page**
   - Navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right corner)

2. **Load Extension**
   - Click "Load unpacked"
   - Select the `Cyberguard` folder
   - Extension should appear in the list

3. **Pin Extension**
   - Click the puzzle piece icon in the toolbar
   - Pin "Cyber Guard Pro" for easy access

### 2. Core Functionality Tests

#### Test 1: Popup Interface
- **Action**: Click the Cyber Guard Pro icon
- **Expected**: Modern glassmorphic popup opens
- **Verify**: 
  - Stats display (threats blocked, privacy score, time saved)
  - Quick scan button works
  - Protection toggle functions
  - Settings and dashboard links work

#### Test 2: Dashboard Access
- **Action**: Click "Open Dashboard" in popup
- **Expected**: New tab opens with comprehensive dashboard
- **Verify**:
  - Security overview cards display
  - Privacy analytics section shows data
  - Achievement system displays progress
  - Charts render correctly (requires Chart.js CDN)
  - Export functionality works

#### Test 3: Security Features
- **Action**: Visit various websites
- **Expected**: Content script monitors and protects
- **Verify**:
  - Password strength analysis on login forms
  - Malicious link detection
  - Form submission protection
  - Privacy score updates in real-time

#### Test 4: Achievement System
- **Action**: Use extension features
- **Expected**: Achievements unlock progressively
- **Verify**:
  - Points accumulate
  - Level progression works
  - Notifications appear for new achievements
  - Achievement history saves

### 3. Advanced Feature Tests

#### Test 5: Threat Detection
- **Test Sites**: 
  - phishing-sites.com (for phishing detection)
  - Various social media sites (for time tracking)
  - Forms with weak passwords
- **Expected**: Appropriate warnings and scoring

#### Test 6: Privacy Analytics
- **Action**: Browse different types of sites
- **Expected**: Privacy exposure tracking
- **Verify**:
  - Data exposure categories tracked
  - Privacy score calculations
  - Real-time updates in dashboard

#### Test 7: Background Processing
- **Action**: Leave extension running
- **Expected**: Periodic scans and daily resets
- **Verify**:
  - Alarms trigger correctly
  - Data persists across browser sessions
  - Performance remains optimal

### 4. Error Testing

#### Test 8: Permission Handling
- **Action**: Test on restricted sites (chrome://, file://)
- **Expected**: Graceful handling of permission limitations

#### Test 9: Network Issues
- **Action**: Test with poor/no internet connection
- **Expected**: Offline functionality maintained

#### Test 10: Data Corruption
- **Action**: Clear extension storage and reload
- **Expected**: Clean initialization with default values

### 5. Performance Verification

#### Memory Usage
- Check Chrome Task Manager (`Shift+Esc`)
- Extension should use minimal memory (<50MB typical)

#### CPU Usage
- Monitor during active browsing
- Should not impact browser performance

#### Storage Usage
- Check `chrome://extensions/` → Cyber Guard Pro → Storage
- Verify reasonable data usage

### 6. Cross-Browser Testing

#### Chromium-based Browsers
- **Microsoft Edge**: Load as developer extension
- **Brave Browser**: Test privacy features integration
- **Opera**: Verify UI compatibility

### 7. Troubleshooting Common Issues

#### Extension Not Loading
- Check manifest.json syntax
- Verify all file paths are correct
- Ensure permissions are granted

#### Dashboard Not Opening
- Check popup blocker settings
- Verify web_accessible_resources in manifest
- Test Chart.js CDN connectivity

#### Content Script Issues
- Check console errors (F12)
- Verify host_permissions in manifest
- Test on different website types

#### Achievement System Problems
- Check background script console
- Verify achievements.json loading
- Test storage persistence

### 8. Expected Behaviors

#### Normal Operation
- ✅ Popup opens quickly (<1 second)
- ✅ Dashboard loads with all components
- ✅ Real-time updates appear
- ✅ Achievements unlock naturally
- ✅ Privacy scores update dynamically
- ✅ No console errors in normal use

#### Security Responses
- 🔒 Phishing sites trigger warnings
- 🔒 Weak passwords show strength indicators
- 🔒 Suspicious forms trigger protection
- 🔒 Privacy exposures update scores

### 9. Success Criteria

The extension is working correctly if:
1. All UI components render properly
2. Security features respond to threats
3. Achievement system tracks progress
4. Privacy analytics update in real-time
5. No critical errors in console
6. Performance impact is minimal
7. Data persists across sessions

### 10. Reporting Issues

If you encounter any issues:
1. Note the specific action that caused the problem
2. Check browser console for errors
3. Verify extension permissions
4. Try reloading the extension
5. Test on different websites/browsers

## Development Notes

- Extension uses Manifest V3 standards
- Modern ES6+ JavaScript features
- Object-oriented architecture
- Comprehensive error handling
- Optimized for performance and security

Ready for production deployment! 🚀
